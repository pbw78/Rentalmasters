# RentalMaster - Property Management System

## Overview

RentalMaster is a comprehensive property management system built with modern web technologies. It provides a complete solution for managing rental properties, tenants, contracts, payments, and service requests. The application features a React frontend with a Node.js/Express backend, using PostgreSQL for data persistence and Replit Auth for authentication.

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for type safety
- **Vite** as the build tool and development server
- **Tailwind CSS** for styling with shadcn/ui component library
- **Wouter** for client-side routing
- **React Query** for server state management and caching
- **React Hook Form** with Zod for form validation

### Backend Architecture
- **Node.js** with Express framework
- **TypeScript** for type safety across the entire stack
- **RESTful API** design with proper HTTP status codes
- **Session-based authentication** using Replit Auth
- **Middleware** for request logging and error handling

### Database Architecture
- **PostgreSQL** as the primary database
- **Drizzle ORM** for type-safe database operations
- **Neon Serverless** for database connections
- **Schema-first approach** with shared types between frontend and backend

## Key Components

### Authentication System
- **Replit Auth** integration with OpenID Connect
- **Session management** with PostgreSQL session store
- **Role-based access control** (user/admin roles)
- **Automatic user provisioning** on first login

### Data Models
- **Users**: Authentication and profile management
- **Properties**: Real estate assets with detailed information
- **Tenants**: Customer information and emergency contacts
- **Contracts**: Rental agreements linking properties and tenants
- **Payments**: Financial transactions and payment tracking
- **Service Requests**: Maintenance and repair management

### UI Components
- **Responsive design** with mobile-first approach
- **Internationalization** support (Polish, English, Danish)
- **Modular component system** using shadcn/ui
- **Form components** with validation and error handling
- **Data tables** with filtering and sorting capabilities

## Data Flow

### Client-Server Communication
1. **API Requests**: Frontend makes authenticated HTTP requests to backend
2. **Session Validation**: Server validates session cookies for each request
3. **Data Processing**: Backend processes requests using Drizzle ORM
4. **Response Handling**: Frontend updates UI using React Query cache
5. **Error Management**: Centralized error handling with user-friendly messages

### Database Operations
1. **Schema Definition**: Shared schema between frontend and backend
2. **Type Safety**: Drizzle generates TypeScript types from schema
3. **Query Optimization**: Efficient queries with proper indexing
4. **Transaction Support**: ACID compliance for data integrity

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection pooling
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui**: Accessible UI primitives
- **react-hook-form**: Form management
- **zod**: Schema validation

### Development Dependencies
- **Vite**: Build tool and development server
- **TypeScript**: Type safety
- **Tailwind CSS**: Utility-first CSS framework
- **ESBuild**: Fast JavaScript bundler

### Authentication Dependencies
- **openid-client**: OpenID Connect client
- **passport**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

## Deployment Strategy

### Development Environment
- **Replit**: Cloud-based development environment
- **Hot Module Replacement**: Instant updates during development
- **Environment Variables**: Secure configuration management
- **Database Provisioning**: Automatic PostgreSQL setup

### Production Deployment
- **Build Process**: Vite builds frontend, esbuild bundles backend
- **Static Asset Serving**: Express serves built frontend files
- **Process Management**: Single Node.js process handles all requests
- **Database Migrations**: Drizzle Kit manages schema changes

### Configuration
- **Environment-based**: Different settings for development/production
- **Secret Management**: Secure handling of API keys and database URLs
- **CORS Configuration**: Proper cross-origin request handling
- **Session Configuration**: Secure cookie settings for production

## Changelog

```
Changelog:
- June 14, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```