import {
  users,
  properties,
  tenants,
  contracts,
  serviceRequests,
  payments,
  type User,
  type UpsertUser,
  type Property,
  type InsertProperty,
  type Tenant,
  type InsertTenant,
  type Contract,
  type InsertContract,
  type ServiceRequest,
  type InsertServiceRequest,
  type Payment,
  type InsertPayment,
  type PropertyWithRelations,
  type TenantWithRelations,
  type ContractWithRelations,
  type ServiceRequestWithRelations,
  type PaymentWithRelations,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Property operations
  getProperties(): Promise<PropertyWithRelations[]>;
  getProperty(id: number): Promise<PropertyWithRelations | undefined>;
  createProperty(property: InsertProperty): Promise<Property>;
  updateProperty(id: number, property: Partial<InsertProperty>): Promise<Property>;
  deleteProperty(id: number): Promise<void>;

  // Tenant operations
  getTenants(): Promise<TenantWithRelations[]>;
  getTenant(id: number): Promise<TenantWithRelations | undefined>;
  createTenant(tenant: InsertTenant): Promise<Tenant>;
  updateTenant(id: number, tenant: Partial<InsertTenant>): Promise<Tenant>;
  deleteTenant(id: number): Promise<void>;

  // Contract operations
  getContracts(): Promise<ContractWithRelations[]>;
  getContract(id: number): Promise<ContractWithRelations | undefined>;
  createContract(contract: InsertContract): Promise<Contract>;
  updateContract(id: number, contract: Partial<InsertContract>): Promise<Contract>;
  deleteContract(id: number): Promise<void>;

  // Service Request operations
  getServiceRequests(): Promise<ServiceRequestWithRelations[]>;
  getServiceRequest(id: number): Promise<ServiceRequestWithRelations | undefined>;
  createServiceRequest(request: InsertServiceRequest): Promise<ServiceRequest>;
  updateServiceRequest(id: number, request: Partial<InsertServiceRequest>): Promise<ServiceRequest>;
  deleteServiceRequest(id: number): Promise<void>;

  // Payment operations
  getPayments(): Promise<PaymentWithRelations[]>;
  getPayment(id: number): Promise<PaymentWithRelations | undefined>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePayment(id: number, payment: Partial<InsertPayment>): Promise<Payment>;
  deletePayment(id: number): Promise<void>;

  // Analytics
  getDashboardStats(): Promise<{
    totalProperties: number;
    activeContracts: number;
    monthlyRevenue: number;
    pendingPayments: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Property operations
  async getProperties(): Promise<PropertyWithRelations[]> {
    const result = await db.query.properties.findMany({
      with: {
        contracts: true,
        serviceRequests: true,
      },
      orderBy: [desc(properties.createdAt)],
    });
    return result;
  }

  async getProperty(id: number): Promise<PropertyWithRelations | undefined> {
    const result = await db.query.properties.findFirst({
      where: eq(properties.id, id),
      with: {
        contracts: true,
        serviceRequests: true,
      },
    });
    return result;
  }

  async createProperty(property: InsertProperty): Promise<Property> {
    const [result] = await db.insert(properties).values(property).returning();
    return result;
  }

  async updateProperty(id: number, property: Partial<InsertProperty>): Promise<Property> {
    const [result] = await db
      .update(properties)
      .set({ ...property, updatedAt: new Date() })
      .where(eq(properties.id, id))
      .returning();
    return result;
  }

  async deleteProperty(id: number): Promise<void> {
    await db.delete(properties).where(eq(properties.id, id));
  }

  // Tenant operations
  async getTenants(): Promise<TenantWithRelations[]> {
    const result = await db.query.tenants.findMany({
      with: {
        contracts: true,
        serviceRequests: true,
      },
      orderBy: [desc(tenants.createdAt)],
    });
    return result;
  }

  async getTenant(id: number): Promise<TenantWithRelations | undefined> {
    const result = await db.query.tenants.findFirst({
      where: eq(tenants.id, id),
      with: {
        contracts: true,
        serviceRequests: true,
      },
    });
    return result;
  }

  async createTenant(tenant: InsertTenant): Promise<Tenant> {
    const [result] = await db.insert(tenants).values(tenant).returning();
    return result;
  }

  async updateTenant(id: number, tenant: Partial<InsertTenant>): Promise<Tenant> {
    const [result] = await db
      .update(tenants)
      .set({ ...tenant, updatedAt: new Date() })
      .where(eq(tenants.id, id))
      .returning();
    return result;
  }

  async deleteTenant(id: number): Promise<void> {
    await db.delete(tenants).where(eq(tenants.id, id));
  }

  // Contract operations
  async getContracts(): Promise<ContractWithRelations[]> {
    const result = await db.query.contracts.findMany({
      with: {
        property: true,
        tenant: true,
        payments: true,
      },
      orderBy: [desc(contracts.createdAt)],
    });
    return result;
  }

  async getContract(id: number): Promise<ContractWithRelations | undefined> {
    const result = await db.query.contracts.findFirst({
      where: eq(contracts.id, id),
      with: {
        property: true,
        tenant: true,
        payments: true,
      },
    });
    return result;
  }

  async createContract(contract: InsertContract): Promise<Contract> {
    const [result] = await db.insert(contracts).values(contract).returning();
    
    // Update property status to 'rented' when contract is created
    await db
      .update(properties)
      .set({ status: 'rented', updatedAt: new Date() })
      .where(eq(properties.id, contract.propertyId));
    
    return result;
  }

  async updateContract(id: number, contract: Partial<InsertContract>): Promise<Contract> {
    const [result] = await db
      .update(contracts)
      .set({ ...contract, updatedAt: new Date() })
      .where(eq(contracts.id, id))
      .returning();
    return result;
  }

  async deleteContract(id: number): Promise<void> {
    // Get the contract to update property status
    const [contractToDelete] = await db
      .select()
      .from(contracts)
      .where(eq(contracts.id, id));
    
    if (contractToDelete) {
      // Update property status back to 'available'
      await db
        .update(properties)
        .set({ status: 'available', updatedAt: new Date() })
        .where(eq(properties.id, contractToDelete.propertyId));
    }
    
    await db.delete(contracts).where(eq(contracts.id, id));
  }

  // Service Request operations
  async getServiceRequests(): Promise<ServiceRequestWithRelations[]> {
    const result = await db.query.serviceRequests.findMany({
      with: {
        property: true,
        tenant: true,
      },
      orderBy: [desc(serviceRequests.createdAt)],
    });
    return result as ServiceRequestWithRelations[];
  }

  async getServiceRequest(id: number): Promise<ServiceRequestWithRelations | undefined> {
    const result = await db.query.serviceRequests.findFirst({
      where: eq(serviceRequests.id, id),
      with: {
        property: true,
        tenant: true,
      },
    });
    return result as ServiceRequestWithRelations | undefined;
  }

  async createServiceRequest(request: InsertServiceRequest): Promise<ServiceRequest> {
    const [result] = await db.insert(serviceRequests).values(request).returning();
    return result;
  }

  async updateServiceRequest(id: number, request: Partial<InsertServiceRequest>): Promise<ServiceRequest> {
    const [result] = await db
      .update(serviceRequests)
      .set({ ...request, updatedAt: new Date() })
      .where(eq(serviceRequests.id, id))
      .returning();
    return result;
  }

  async deleteServiceRequest(id: number): Promise<void> {
    await db.delete(serviceRequests).where(eq(serviceRequests.id, id));
  }

  // Payment operations
  async getPayments(): Promise<PaymentWithRelations[]> {
    const result = await db.query.payments.findMany({
      with: {
        contract: {
          with: {
            property: true,
            tenant: true,
            payments: true,
          },
        },
      },
      orderBy: [desc(payments.createdAt)],
    });
    return result;
  }

  async getPayment(id: number): Promise<PaymentWithRelations | undefined> {
    const result = await db.query.payments.findFirst({
      where: eq(payments.id, id),
      with: {
        contract: {
          with: {
            property: true,
            tenant: true,
            payments: true,
          },
        },
      },
    });
    return result;
  }

  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [result] = await db.insert(payments).values(payment).returning();
    return result;
  }

  async updatePayment(id: number, payment: Partial<InsertPayment>): Promise<Payment> {
    const [result] = await db
      .update(payments)
      .set({ ...payment, updatedAt: new Date() })
      .where(eq(payments.id, id))
      .returning();
    return result;
  }

  async deletePayment(id: number): Promise<void> {
    await db.delete(payments).where(eq(payments.id, id));
  }

  // Analytics
  async getDashboardStats(): Promise<{
    totalProperties: number;
    activeContracts: number;
    monthlyRevenue: number;
    pendingPayments: number;
  }> {
    const [totalPropertiesResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(properties);

    const [activeContractsResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(contracts)
      .where(eq(contracts.status, 'active'));

    const [monthlyRevenueResult] = await db
      .select({ sum: sql<number>`sum(${contracts.monthlyRent})` })
      .from(contracts)
      .where(eq(contracts.status, 'active'));

    const [pendingPaymentsResult] = await db
      .select({ sum: sql<number>`sum(${payments.amount})` })
      .from(payments)
      .where(eq(payments.status, 'pending'));

    return {
      totalProperties: totalPropertiesResult.count || 0,
      activeContracts: activeContractsResult.count || 0,
      monthlyRevenue: monthlyRevenueResult.sum || 0,
      pendingPayments: pendingPaymentsResult.sum || 0,
    };
  }
}

export const storage = new DatabaseStorage();
