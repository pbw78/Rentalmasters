import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'pl' | 'en' | 'da';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}

interface LanguageProviderProps {
  children: ReactNode;
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [language, setLanguageState] = useState<Language>('pl');

  useEffect(() => {
    const saved = localStorage.getItem('rentalmaster_language') as Language;
    if (saved && ['pl', 'en', 'da'].includes(saved)) {
      setLanguageState(saved);
    }
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('rentalmaster_language', lang);
  };

  const translations = {
    pl: {
      // Navigation
      dashboard: 'Dashboard',
      properties: 'Nieruchomości',
      tenants: 'Najemcy',
      contracts: 'Umowy',
      payments: 'Płatności',
      service: 'Serwis',
      reports: 'Raporty',
      admin: 'Panel Admin',
      
      // Dashboard
      totalProperties: 'Łączne nieruchomości',
      activeContracts: 'Aktywne umowy',
      monthlyRevenue: 'Miesięczne przychody',
      pendingPayments: 'Oczekujące płatności',
      recentActivity: 'Ostatnia aktywność',
      quickActions: 'Szybkie akcje',
      
      // Actions
      addProperty: 'Dodaj nieruchomość',
      addTenant: 'Dodaj najemcę',
      createContract: 'Utwórz umowę',
      downloadReport: 'Pobierz raport',
      edit: 'Edytuj',
      delete: 'Usuń',
      save: 'Zapisz',
      cancel: 'Anuluj',
      
      // Forms
      address: 'Adres',
      type: 'Typ',
      area: 'Powierzchnia',
      rooms: 'Pokoje',
      bathrooms: 'Łazienki',
      monthlyRent: 'Czynsz miesięczny',
      deposit: 'Kaucja',
      description: 'Opis',
      firstName: 'Imię',
      lastName: 'Nazwisko',
      email: 'Email',
      phone: 'Telefon',
      dateOfBirth: 'Data urodzenia',
      emergencyContact: 'Kontakt awaryjny',
      
      // Status
      available: 'Dostępne',
      rented: 'Wynajęte',
      maintenance: 'W remoncie',
      unavailable: 'Niedostępne',
      active: 'Aktywne',
      inactive: 'Nieaktywne',
      
      // Messages
      loginSuccess: 'Zalogowano pomyślnie!',
      loginError: 'Nieprawidłowe dane logowania',
      saveSuccess: 'Zapisano pomyślnie',
      deleteSuccess: 'Usunięto pomyślnie',
      error: 'Wystąpił błąd',
    },
    en: {
      // Navigation
      dashboard: 'Dashboard',
      properties: 'Properties',
      tenants: 'Tenants',
      contracts: 'Contracts',
      payments: 'Payments',
      service: 'Service',
      reports: 'Reports',
      admin: 'Admin Panel',
      
      // Dashboard
      totalProperties: 'Total Properties',
      activeContracts: 'Active Contracts',
      monthlyRevenue: 'Monthly Revenue',
      pendingPayments: 'Pending Payments',
      recentActivity: 'Recent Activity',
      quickActions: 'Quick Actions',
      
      // Actions
      addProperty: 'Add Property',
      addTenant: 'Add Tenant',
      createContract: 'Create Contract',
      downloadReport: 'Download Report',
      edit: 'Edit',
      delete: 'Delete',
      save: 'Save',
      cancel: 'Cancel',
      
      // Forms
      address: 'Address',
      type: 'Type',
      area: 'Area',
      rooms: 'Rooms',
      bathrooms: 'Bathrooms',
      monthlyRent: 'Monthly Rent',
      deposit: 'Deposit',
      description: 'Description',
      firstName: 'First Name',
      lastName: 'Last Name',
      email: 'Email',
      phone: 'Phone',
      dateOfBirth: 'Date of Birth',
      emergencyContact: 'Emergency Contact',
      
      // Status
      available: 'Available',
      rented: 'Rented',
      maintenance: 'Maintenance',
      unavailable: 'Unavailable',
      active: 'Active',
      inactive: 'Inactive',
      
      // Messages
      loginSuccess: 'Login successful!',
      loginError: 'Invalid login credentials',
      saveSuccess: 'Saved successfully',
      deleteSuccess: 'Deleted successfully',
      error: 'An error occurred',
    },
    da: {
      // Navigation
      dashboard: 'Dashboard',
      properties: 'Ejendomme',
      tenants: 'Lejere',
      contracts: 'Kontrakter',
      payments: 'Betalinger',
      service: 'Service',
      reports: 'Rapporter',
      admin: 'Admin Panel',
      
      // Dashboard
      totalProperties: 'Samlede Ejendomme',
      activeContracts: 'Aktive Kontrakter',
      monthlyRevenue: 'Månedlig Indtægt',
      pendingPayments: 'Ventende Betalinger',
      recentActivity: 'Seneste Aktivitet',
      quickActions: 'Hurtige Handlinger',
      
      // Actions
      addProperty: 'Tilføj Ejendom',
      addTenant: 'Tilføj Lejer',
      createContract: 'Opret Kontrakt',
      downloadReport: 'Download Rapport',
      edit: 'Rediger',
      delete: 'Slet',
      save: 'Gem',
      cancel: 'Annuller',
      
      // Forms
      address: 'Adresse',
      type: 'Type',
      area: 'Areal',
      rooms: 'Værelser',
      bathrooms: 'Badeværelser',
      monthlyRent: 'Månedlig Leje',
      deposit: 'Depositum',
      description: 'Beskrivelse',
      firstName: 'Fornavn',
      lastName: 'Efternavn',
      email: 'Email',
      phone: 'Telefon',
      dateOfBirth: 'Fødselsdato',
      emergencyContact: 'Nødkontakt',
      
      // Status
      available: 'Tilgængelig',
      rented: 'Udlejet',
      maintenance: 'Vedligeholdelse',
      unavailable: 'Ikke tilgængelig',
      active: 'Aktiv',
      inactive: 'Inaktiv',
      
      // Messages
      loginSuccess: 'Login succesfuldt!',
      loginError: 'Ugyldige login oplysninger',
      saveSuccess: 'Gemt succesfuldt',
      deleteSuccess: 'Slettet succesfuldt',
      error: 'Der opstod en fejl',
    },
  };

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['pl']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}
