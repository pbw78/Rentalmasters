import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { SimpleTenantForm } from "@/components/SimpleTenantForm";
import { BulkOperations } from "@/components/BulkOperations";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Plus, Edit, Trash2, Download, User, Search } from "lucide-react";
import type { Tenant, TenantWithRelations, InsertTenant } from "@shared/schema";

export default function Tenants() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingTenant, setEditingTenant] = useState<Tenant | null>(null);
  const [deletingTenant, setDeletingTenant] = useState<Tenant | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tenants = [], isLoading, error } = useQuery<TenantWithRelations[]>({
    queryKey: ["/api/tenants"],
  });

  // Handle unauthorized errors
  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [error, toast]);

  const createTenantMutation = useMutation({
    mutationFn: async (data: InsertTenant) => {
      await apiRequest("POST", "/api/tenants", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenants"] });
      setShowAddModal(false);
      toast({
        title: t("saveSuccess"),
        description: "Najemca został dodany pomyślnie",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się dodać najemcy",
        variant: "destructive",
      });
    },
  });

  const updateTenantMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: InsertTenant }) => {
      await apiRequest("PUT", `/api/tenants/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenants"] });
      setEditingTenant(null);
      toast({
        title: t("saveSuccess"),
        description: "Najemca został zaktualizowany pomyślnie",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się zaktualizować najemcy",
        variant: "destructive",
      });
    },
  });

  const deleteTenantMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/tenants/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenants"] });
      setDeletingTenant(null);
      toast({
        title: t("deleteSuccess"),
        description: "Najemca został usunięty pomyślnie",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się usunąć najemcy",
        variant: "destructive",
      });
    },
  });

  const handleExport = () => {
    window.open("/api/export/tenants", "_blank");
  };

  const calculateAge = (dateOfBirth: string | null) => {
    if (!dateOfBirth) return "N/A";
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return `${age} lat`;
  };

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
  };

  const filteredTenants = tenants.filter((tenant) =>
    `${tenant.firstName} ${tenant.lastName} ${tenant.email}`
      .toLowerCase()
      .includes(searchQuery.toLowerCase())
  );

  const getActiveContract = (tenant: TenantWithRelations) => {
    return tenant.contracts?.find(contract => contract.status === 'active');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar
          onSidebarToggle={() => setSidebarOpen(true)}
          title={t("tenants")}
          description="Zarządzaj bazą najemców"
        />

        <main className="flex-1 p-6 overflow-auto">
          {/* Header with Add Button */}
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">{t("tenants")}</h2>
              <p className="text-slate-600">Zarządzaj bazą najemców</p>
            </div>
            <div className="flex space-x-3">
              <Button onClick={handleExport} variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Excel
              </Button>
              <Button onClick={() => setShowAddModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                {t("addTenant")}
              </Button>
            </div>
          </div>

          {/* Bulk Operations */}
          <div className="mb-6">
            <BulkOperations 
              module="tenants" 
              onSuccess={() => queryClient.invalidateQueries({ queryKey: ["/api/tenants"] })}
            />
          </div>

          {/* Tenants Table */}
          <Card>
            <CardContent className="p-0">
              <div className="px-6 py-4 border-b border-slate-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-slate-800">Lista najemców</h3>
                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                      <Input
                        placeholder="Szukaj najemców..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {isLoading ? (
                <div className="p-8 text-center">
                  <div className="animate-pulse space-y-4">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-slate-200 rounded-full" />
                        <div className="flex-1 space-y-2">
                          <div className="h-4 bg-slate-200 rounded w-1/4" />
                          <div className="h-3 bg-slate-200 rounded w-1/3" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : filteredTenants.length === 0 ? (
                <div className="p-12 text-center">
                  <div className="text-slate-400 mb-4">
                    <User className="w-12 h-12 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-slate-900 mb-2">
                    Brak najemców
                  </h3>
                  <p className="text-slate-500 mb-4">
                    {searchQuery ? "Nie znaleziono najemców spełniających kryteria wyszukiwania." : "Dodaj pierwszego najemcę do systemu."}
                  </p>
                  <Button onClick={() => setShowAddModal(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Dodaj najemcę
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Najemca</TableHead>
                        <TableHead>Kontakt</TableHead>
                        <TableHead>Nieruchomość</TableHead>
                        <TableHead>Status umowy</TableHead>
                        <TableHead>Akcje</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredTenants.map((tenant) => {
                        const activeContract = getActiveContract(tenant);
                        return (
                          <TableRow key={tenant.id} className="hover:bg-slate-50">
                            <TableCell>
                              <div className="flex items-center space-x-3">
                                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                                  <span className="text-primary font-medium text-sm">
                                    {getInitials(tenant.firstName, tenant.lastName)}
                                  </span>
                                </div>
                                <div>
                                  <div className="text-sm font-medium text-slate-900">
                                    {tenant.firstName} {tenant.lastName}
                                  </div>
                                  <div className="text-sm text-slate-500">
                                    {calculateAge(tenant.dateOfBirth)}
                                  </div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="text-sm text-slate-900">{tenant.email}</div>
                              <div className="text-sm text-slate-500">{tenant.phone || "Brak telefonu"}</div>
                            </TableCell>
                            <TableCell>
                              {activeContract ? (
                                <div>
                                  <div className="text-sm text-slate-900">
                                    Umowa aktywna
                                  </div>
                                  <div className="text-sm text-slate-500">
                                    {parseFloat(activeContract.monthlyRent).toLocaleString('pl-PL')} zł/mies.
                                  </div>
                                </div>
                              ) : (
                                <div className="text-sm text-slate-500">Brak aktywnej umowy</div>
                              )}
                            </TableCell>
                            <TableCell>
                              {activeContract ? (
                                <Badge className="status-badge status-rented">Aktywna</Badge>
                              ) : tenant.isActive ? (
                                <Badge className="status-badge status-available">Dostępny</Badge>
                              ) : (
                                <Badge className="status-badge status-unavailable">Nieaktywny</Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => setEditingTenant(tenant)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => setDeletingTenant(tenant)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      {/* Add Tenant Modal */}
      <Dialog open={showAddModal} onOpenChange={setShowAddModal}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Dodaj nowego najemcę</DialogTitle>
          </DialogHeader>
          <SimpleTenantForm
            onSubmit={(data) => createTenantMutation.mutate(data)}
            onCancel={() => setShowAddModal(false)}
            isLoading={createTenantMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Tenant Modal */}
      <Dialog open={!!editingTenant} onOpenChange={() => setEditingTenant(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edytuj najemcę</DialogTitle>
          </DialogHeader>
          {editingTenant && (
            <SimpleTenantForm
              tenant={editingTenant}
              onSubmit={(data) => 
                updateTenantMutation.mutate({ id: editingTenant.id, data })
              }
              onCancel={() => setEditingTenant(null)}
              isLoading={updateTenantMutation.isPending}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deletingTenant} onOpenChange={() => setDeletingTenant(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Potwierdź usunięcie</AlertDialogTitle>
            <AlertDialogDescription>
              Czy na pewno chcesz usunąć najemcę "{deletingTenant?.firstName} {deletingTenant?.lastName}"? 
              Ta operacja nie może zostać cofnięta.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Anuluj</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingTenant && deleteTenantMutation.mutate(deletingTenant.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Usuń
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
