import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  Plus, 
  Download, 
  Eye, 
  Check, 
  Bell, 
  TrendingDown, 
  AlertTriangle, 
  Clock, 
  Calculator 
} from "lucide-react";
import type { PaymentWithRelations } from "@shared/schema";

interface PaymentStats {
  receivedThisMonth: number;
  overdue: number;
  pending: number;
  averagePayment: number;
}

export default function Payments() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState("");

  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: payments = [], isLoading, error } = useQuery<PaymentWithRelations[]>({
    queryKey: ["/api/payments"],
  });

  // Handle unauthorized errors
  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [error, toast]);

  const markAsPaidMutation = useMutation({
    mutationFn: async (paymentId: number) => {
      await apiRequest("PUT", `/api/payments/${paymentId}`, {
        status: "paid",
        paidDate: new Date().toISOString().split('T')[0],
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      toast({
        title: "Sukces",
        description: "Płatność została oznaczona jako opłacona",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się zaktualizować płatności",
        variant: "destructive",
      });
    },
  });

  const getPaymentStats = (): PaymentStats => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const receivedThisMonth = payments
      .filter(p => {
        if (!p.paidDate) return false;
        const paidDate = new Date(p.paidDate);
        return paidDate.getMonth() === currentMonth && paidDate.getFullYear() === currentYear;
      })
      .reduce((sum, p) => sum + parseFloat(p.amount), 0);

    const overdue = payments
      .filter(p => {
        if (p.status !== 'pending') return false;
        return new Date(p.dueDate) < new Date();
      })
      .reduce((sum, p) => sum + parseFloat(p.amount), 0);

    const pending = payments
      .filter(p => p.status === 'pending')
      .reduce((sum, p) => sum + parseFloat(p.amount), 0);

    const averagePayment = payments.length > 0 
      ? payments.reduce((sum, p) => sum + parseFloat(p.amount), 0) / payments.length 
      : 0;

    return { receivedThisMonth, overdue, pending, averagePayment };
  };

  const getStatusBadge = (status: string, dueDate: string) => {
    if (status === "paid") {
      return <Badge className="status-badge status-rented">Opłacone</Badge>;
    }
    
    if (status === "pending") {
      const today = new Date();
      const due = new Date(dueDate);
      const daysOverdue = Math.floor((today.getTime() - due.getTime()) / (1000 * 3600 * 24));
      
      if (daysOverdue > 0) {
        return (
          <Badge className="status-badge status-unavailable">
            Zaległe ({daysOverdue} dni)
          </Badge>
        );
      }
      return <Badge className="status-badge bg-amber-100 text-amber-800">Oczekujące</Badge>;
    }

    return <Badge className="status-badge bg-gray-100 text-gray-800">{status}</Badge>;
  };

  const getDaysOverdue = (dueDate: string) => {
    const today = new Date();
    const due = new Date(dueDate);
    return Math.floor((today.getTime() - due.getTime()) / (1000 * 3600 * 24));
  };

  const stats = getPaymentStats();
  const filteredPayments = payments.filter(payment => 
    !statusFilter || payment.status === statusFilter
  );

  const statsCards = [
    {
      title: "Otrzymane w tym miesiącu",
      value: stats.receivedThisMonth.toLocaleString('pl-PL', { style: 'currency', currency: 'PLN' }),
      icon: TrendingDown,
      color: "bg-green-500",
    },
    {
      title: "Zaległości",
      value: stats.overdue.toLocaleString('pl-PL', { style: 'currency', currency: 'PLN' }),
      icon: AlertTriangle,
      color: "bg-red-500",
    },
    {
      title: "Oczekujące płatności",
      value: stats.pending.toLocaleString('pl-PL', { style: 'currency', currency: 'PLN' }),
      icon: Clock,
      color: "bg-amber-500",
    },
    {
      title: "Średnia płatność",
      value: stats.averagePayment.toLocaleString('pl-PL', { style: 'currency', currency: 'PLN' }),
      icon: Calculator,
      color: "bg-blue-500",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar
          onSidebarToggle={() => setSidebarOpen(true)}
          title={t("payments")}
          description="Zarządzaj płatnościami i fakturami"
        />

        <main className="flex-1 p-6 overflow-auto">
          {/* Header with Actions */}
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">{t("payments")}</h2>
              <p className="text-slate-600">Zarządzaj płatnościami i fakturami</p>
            </div>
            <div className="flex space-x-3">
              <Button variant="outline">
                <Bell className="h-4 w-4 mr-2" />
                Generuj faktury
              </Button>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Dodaj płatność
              </Button>
            </div>
          </div>

          {/* Payment Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            {statsCards.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-slate-500 text-sm font-medium">{stat.title}</p>
                        <p className="text-2xl font-bold text-slate-800">{stat.value}</p>
                      </div>
                      <div className={`w-10 h-10 ${stat.color} rounded-lg flex items-center justify-center`}>
                        <Icon className="h-5 w-5 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Payments Table */}
          <Card>
            <CardContent className="p-0">
              <div className="px-6 py-4 border-b border-slate-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-slate-800">Ostatnie płatności</h3>
                  <div className="flex items-center space-x-2">
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Wszystkie" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Wszystkie</SelectItem>
                        <SelectItem value="paid">Opłacone</SelectItem>
                        <SelectItem value="pending">Oczekujące</SelectItem>
                        <SelectItem value="overdue">Zaległe</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Excel
                    </Button>
                  </div>
                </div>
              </div>

              {isLoading ? (
                <div className="p-8">
                  <div className="animate-pulse space-y-4">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="flex items-center space-x-4">
                        <div className="w-8 h-8 bg-slate-200 rounded" />
                        <div className="flex-1 space-y-2">
                          <div className="h-4 bg-slate-200 rounded w-1/4" />
                          <div className="h-3 bg-slate-200 rounded w-1/3" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : filteredPayments.length === 0 ? (
                <div className="p-12 text-center">
                  <div className="text-slate-400 mb-4">
                    <Calculator className="w-12 h-12 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-slate-900 mb-2">
                    Brak płatności
                  </h3>
                  <p className="text-slate-500 mb-4">
                    {statusFilter ? "Nie znaleziono płatności o wybranym statusie." : "Dodaj pierwszą płatność do systemu."}
                  </p>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Dodaj płatność
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Najemca</TableHead>
                        <TableHead>Nieruchomość</TableHead>
                        <TableHead>Kwota</TableHead>
                        <TableHead>Termin</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Akcje</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPayments.map((payment) => {
                        const daysOverdue = getDaysOverdue(payment.dueDate);
                        return (
                          <TableRow key={payment.id} className="hover:bg-slate-50">
                            <TableCell>
                              <div className="text-sm font-medium text-slate-900">
                                {payment.contract?.tenant?.firstName} {payment.contract?.tenant?.lastName}
                              </div>
                              <div className="text-sm text-slate-500">
                                {payment.contract?.tenant?.email}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="text-sm text-slate-900">
                                {payment.contract?.property?.address}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="text-sm font-medium text-slate-900">
                                {parseFloat(payment.amount).toLocaleString('pl-PL')} zł
                              </div>
                              <div className="text-sm text-slate-500">
                                {payment.notes || "Czynsz miesięczny"}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className={`text-sm ${daysOverdue > 0 && payment.status === 'pending' ? 'text-red-600' : 'text-slate-900'}`}>
                                {new Date(payment.dueDate).toLocaleDateString('pl-PL')}
                              </div>
                            </TableCell>
                            <TableCell>
                              {getStatusBadge(payment.status || "pending", payment.dueDate)}
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button size="sm" variant="ghost">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="ghost">
                                  <Download className="h-4 w-4" />
                                </Button>
                                {payment.status === 'pending' && (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => markAsPaidMutation.mutate(payment.id)}
                                    disabled={markAsPaidMutation.isPending}
                                  >
                                    <Check className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
