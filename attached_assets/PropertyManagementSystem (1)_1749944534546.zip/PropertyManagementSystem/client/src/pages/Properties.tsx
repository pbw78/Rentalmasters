import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { SimplePropertyForm } from "@/components/SimplePropertyForm";
import { BulkOperations } from "@/components/BulkOperations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Plus, Edit, Trash2, Download } from "lucide-react";
import type { Property, PropertyWithRelations, InsertProperty } from "@shared/schema";

export default function Properties() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);
  const [deletingProperty, setDeletingProperty] = useState<Property | null>(null);
  const [filters, setFilters] = useState({
    type: "",
    status: "",
    minPrice: "",
    maxPrice: "",
  });

  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: properties = [], isLoading, error } = useQuery<PropertyWithRelations[]>({
    queryKey: ["/api/properties"],
  });

  // Handle unauthorized errors
  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [error, toast]);

  const createPropertyMutation = useMutation({
    mutationFn: async (data: InsertProperty) => {
      await apiRequest("POST", "/api/properties", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/properties"] });
      setShowAddModal(false);
      toast({
        title: t("saveSuccess"),
        description: "Nieruchomość została dodana pomyślnie",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się dodać nieruchomości",
        variant: "destructive",
      });
    },
  });

  const updatePropertyMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: InsertProperty }) => {
      await apiRequest("PUT", `/api/properties/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/properties"] });
      setEditingProperty(null);
      toast({
        title: t("saveSuccess"),
        description: "Nieruchomość została zaktualizowana pomyślnie",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się zaktualizować nieruchomości",
        variant: "destructive",
      });
    },
  });

  const deletePropertyMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/properties/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/properties"] });
      setDeletingProperty(null);
      toast({
        title: t("deleteSuccess"),
        description: "Nieruchomość została usunięta pomyślnie",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się usunąć nieruchomości",
        variant: "destructive",
      });
    },
  });

  const handleExport = () => {
    window.open("/api/export/properties", "_blank");
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      available: { label: t("available"), className: "status-available" },
      rented: { label: t("rented"), className: "status-rented" },
      maintenance: { label: t("maintenance"), className: "status-maintenance" },
      unavailable: { label: t("unavailable"), className: "status-unavailable" },
    };
    
    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.available;
    return (
      <Badge className={`status-badge ${statusInfo.className}`}>
        {statusInfo.label}
      </Badge>
    );
  };

  const filteredProperties = properties.filter((property) => {
    const typeMatch = !filters.type || property.type === filters.type;
    const statusMatch = !filters.status || property.status === filters.status;
    const minPriceMatch = !filters.minPrice || parseFloat(property.monthlyRent) >= parseFloat(filters.minPrice);
    const maxPriceMatch = !filters.maxPrice || parseFloat(property.monthlyRent) <= parseFloat(filters.maxPrice);
    
    return typeMatch && statusMatch && minPriceMatch && maxPriceMatch;
  });

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar
          onSidebarToggle={() => setSidebarOpen(true)}
          title={t("properties")}
          description="Zarządzaj swoimi nieruchomościami"
        />

        <main className="flex-1 p-6 overflow-auto">
          {/* Header with Add Button */}
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">{t("properties")}</h2>
              <p className="text-slate-600">Zarządzaj swoimi nieruchomościami</p>
            </div>
            <div className="flex space-x-3">
              <Button onClick={handleExport} variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Eksport
              </Button>
              <Button onClick={() => setShowAddModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                {t("addProperty")}
              </Button>
            </div>
          </div>

          {/* Bulk Operations */}
          <div className="mb-6">
            <BulkOperations 
              module="properties" 
              onSuccess={() => queryClient.invalidateQueries({ queryKey: ["/api/properties"] })}
            />
          </div>

          {/* Filters */}
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Typ nieruchomości
                  </label>
                  <Select value={filters.type} onValueChange={(value) => setFilters(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Wszystkie" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Wszystkie</SelectItem>
                      <SelectItem value="apartment">Mieszkanie</SelectItem>
                      <SelectItem value="house">Dom</SelectItem>
                      <SelectItem value="studio">Studio</SelectItem>
                      <SelectItem value="townhouse">Kamienica</SelectItem>
                      <SelectItem value="loft">Loft</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Status
                  </label>
                  <Select value={filters.status} onValueChange={(value) => setFilters(prev => ({ ...prev, status: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Wszystkie" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Wszystkie</SelectItem>
                      <SelectItem value="available">Dostępne</SelectItem>
                      <SelectItem value="rented">Wynajęte</SelectItem>
                      <SelectItem value="maintenance">W remoncie</SelectItem>
                      <SelectItem value="unavailable">Niedostępne</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Cena od (zł)
                  </label>
                  <Input
                    type="number"
                    placeholder="0"
                    value={filters.minPrice}
                    onChange={(e) => setFilters(prev => ({ ...prev, minPrice: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Cena do (zł)
                  </label>
                  <Input
                    type="number"
                    placeholder="10000"
                    value={filters.maxPrice}
                    onChange={(e) => setFilters(prev => ({ ...prev, maxPrice: e.target.value }))}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Properties Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <div className="h-48 bg-slate-200" />
                  <CardContent className="p-6">
                    <div className="h-4 bg-slate-200 rounded mb-2" />
                    <div className="h-3 bg-slate-200 rounded mb-4" />
                    <div className="flex justify-between">
                      <div className="h-6 bg-slate-200 rounded w-20" />
                      <div className="h-8 bg-slate-200 rounded w-24" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredProperties.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <div className="text-slate-400 mb-4">
                  <svg className="w-12 h-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">
                  Brak nieruchomości
                </h3>
                <p className="text-slate-500 mb-4">
                  Nie znaleziono nieruchomości spełniających kryteria wyszukiwania.
                </p>
                <Button onClick={() => setShowAddModal(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Dodaj pierwszą nieruchomość
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProperties.map((property) => (
                <Card key={property.id} className="property-card">
                  <img
                    src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                    alt="Property"
                    className="property-image"
                  />
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-slate-800 truncate">
                        {property.address}
                      </h3>
                      {getStatusBadge(property.status || "available")}
                    </div>
                    <p className="text-slate-600 text-sm mb-4">
                      {property.type} • {property.rooms || 0} pokoi • {property.area || 0} m²
                    </p>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-2xl font-bold text-slate-800">
                          {parseFloat(property.monthlyRent).toLocaleString('pl-PL')} zł
                        </p>
                        <p className="text-slate-500 text-sm">miesięcznie</p>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setEditingProperty(property)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setDeletingProperty(property)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </main>
      </div>

      {/* Add Property Modal */}
      <Dialog open={showAddModal} onOpenChange={setShowAddModal}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Dodaj nową nieruchomość</DialogTitle>
          </DialogHeader>
          <SimplePropertyForm
            onSubmit={(data) => createPropertyMutation.mutate(data)}
            onCancel={() => setShowAddModal(false)}
            isLoading={createPropertyMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Property Modal */}
      <Dialog open={!!editingProperty} onOpenChange={() => setEditingProperty(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edytuj nieruchomość</DialogTitle>
          </DialogHeader>
          {editingProperty && (
            <SimplePropertyForm
              property={editingProperty}
              onSubmit={(data) => 
                updatePropertyMutation.mutate({ id: editingProperty.id, data })
              }
              onCancel={() => setEditingProperty(null)}
              isLoading={updatePropertyMutation.isPending}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deletingProperty} onOpenChange={() => setDeletingProperty(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Potwierdź usunięcie</AlertDialogTitle>
            <AlertDialogDescription>
              Czy na pewno chcesz usunąć nieruchomość "{deletingProperty?.address}"? 
              Ta operacja nie może zostać cofnięta.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Anuluj</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingProperty && deletePropertyMutation.mutate(deletingProperty.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Usuń
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
