import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  Users, 
  UserCheck, 
  Building, 
  Server, 
  UserPlus,
  Shield,
  Activity,
  Database,
  Clock,
  AlertTriangle,
  CheckCircle,
  Info
} from "lucide-react";
import type { 
  PropertyWithRelations, 
  TenantWithRelations, 
  ContractWithRelations,
  User
} from "@shared/schema";

interface SystemStats {
  totalUsers: number;
  activeUsers: number;
  propertyManagers: number;
  systemUptime: string;
}

interface SystemLog {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success';
  message: string;
  details: string;
  timestamp: string;
}

export default function Admin() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { t } = useLanguage();
  const { toast } = useToast();
  const { user } = useAuth();

  // Redirect non-admin users
  useEffect(() => {
    if (user && user.role !== 'admin') {
      toast({
        title: "Brak uprawnień",
        description: "Nie masz uprawnień do przeglądania panelu administratora",
        variant: "destructive",
      });
      window.location.href = "/";
    }
  }, [user, toast]);

  const { data: properties = [], error: propertiesError } = useQuery<PropertyWithRelations[]>({
    queryKey: ["/api/properties"],
  });

  const { data: tenants = [], error: tenantsError } = useQuery<TenantWithRelations[]>({
    queryKey: ["/api/tenants"],
  });

  const { data: contracts = [], error: contractsError } = useQuery<ContractWithRelations[]>({
    queryKey: ["/api/contracts"],
  });

  // Handle unauthorized errors
  useEffect(() => {
    const errors = [propertiesError, tenantsError, contractsError];
    const unauthorizedError = errors.find(error => error && isUnauthorizedError(error as Error));
    
    if (unauthorizedError) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [propertiesError, tenantsError, contractsError, toast]);

  // Mock system stats - in real app would come from admin API
  const systemStats: SystemStats = {
    totalUsers: 47,
    activeUsers: 42,
    propertyManagers: 12,
    systemUptime: "99.9%",
  };

  // Mock users data - in real app would come from users API
  const mockUsers: User[] = [
    {
      id: "1",
      email: "admin@rentalmaster.com",
      firstName: "Administrator",
      lastName: "System",
      profileImageUrl: null,
      role: "admin",
      createdAt: new Date("2024-01-01"),
      updatedAt: new Date("2024-01-15"),
    },
    {
      id: "2",
      email: "manager@rentalmaster.com",
      firstName: "Jan",
      lastName: "Kowalski",
      profileImageUrl: null,
      role: "manager",
      createdAt: new Date("2024-01-05"),
      updatedAt: new Date("2024-01-10"),
    },
    {
      id: "3",
      email: "user@rentalmaster.com",
      firstName: "Anna",
      lastName: "Nowak",
      profileImageUrl: null,
      role: "user",
      createdAt: new Date("2024-01-10"),
      updatedAt: new Date("2024-01-12"),
    },
  ];

  // Mock system logs - in real app would come from logs API
  const systemLogs: SystemLog[] = [
    {
      id: "1",
      type: "success",
      message: "Nowy użytkownik zarejestrowany",
      details: "jan.kowalski@email.com",
      timestamp: "2 godziny temu"
    },
    {
      id: "2",
      type: "info",
      message: "Backup bazy danych ukończony",
      details: "Automatyczny backup",
      timestamp: "4 godziny temu"
    },
    {
      id: "3",
      type: "warning",
      message: "Próba logowania z nieznanego IP",
      details: "IP: 192.168.1.100",
      timestamp: "6 godzin temu"
    },
    {
      id: "4",
      type: "error",
      message: "Błąd połączenia z bazą danych",
      details: "Połączenie przywrócone po 30 sekundach",
      timestamp: "1 dzień temu"
    }
  ];

  const getStatsCards = () => [
    {
      title: "Łączna liczba użytkowników",
      value: systemStats.totalUsers,
      icon: Users,
      color: "bg-blue-100 text-blue-600",
    },
    {
      title: "Aktywni użytkownicy",
      value: systemStats.activeUsers,
      icon: UserCheck,
      color: "bg-green-100 text-green-600",
    },
    {
      title: "Zarządców nieruchomości",
      value: systemStats.propertyManagers,
      icon: Building,
      color: "bg-primary/10 text-primary",
    },
    {
      title: "System uptime",
      value: systemStats.systemUptime,
      icon: Server,
      color: "bg-slate-100 text-slate-600",
    },
  ];

  const getRoleBadge = (role: string) => {
    const roleMap = {
      admin: { label: "Super Admin", className: "bg-red-100 text-red-800" },
      manager: { label: "Manager", className: "bg-blue-100 text-blue-800" },
      user: { label: "Użytkownik", className: "bg-green-100 text-green-800" },
    };

    const roleInfo = roleMap[role as keyof typeof roleMap] || roleMap.user;
    return (
      <Badge className={`status-badge ${roleInfo.className}`}>
        {roleInfo.label}
      </Badge>
    );
  };

  const getStatusBadge = (isActive: boolean) => {
    return isActive ? (
      <Badge className="status-badge status-rented">Aktywny</Badge>
    ) : (
      <Badge className="status-badge status-unavailable">Nieaktywny</Badge>
    );
  };

  const getLogIcon = (type: string) => {
    const iconMap = {
      success: { icon: CheckCircle, className: "text-green-500" },
      info: { icon: Info, className: "text-blue-500" },
      warning: { icon: AlertTriangle, className: "text-amber-500" },
      error: { icon: AlertTriangle, className: "text-red-500" },
    };

    const iconInfo = iconMap[type as keyof typeof iconMap] || iconMap.info;
    const IconComponent = iconInfo.icon;
    return <IconComponent className={`w-2 h-2 ${iconInfo.className}`} />;
  };

  const getInitials = (firstName: string | null, lastName: string | null) => {
    const first = firstName?.charAt(0) || '';
    const last = lastName?.charAt(0) || '';
    return `${first}${last}`.toUpperCase() || 'U';
  };

  // Don't render if user is not admin
  if (!user || user.role !== 'admin') {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar
          onSidebarToggle={() => setSidebarOpen(true)}
          title={t("admin")}
          description="Zarządzanie systemem i użytkownikami"
        />

        <main className="flex-1 p-6 overflow-auto">
          {/* Header with Add User Button */}
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">{t("admin")}</h2>
              <p className="text-slate-600">Zarządzanie systemem i użytkownikami</p>
            </div>
            <Button>
              <UserPlus className="h-4 w-4 mr-2" />
              Dodaj użytkownika
            </Button>
          </div>

          {/* System Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            {getStatsCards().map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-slate-500 text-sm font-medium">{stat.title}</p>
                        <p className="text-2xl font-bold text-slate-800">{stat.value}</p>
                      </div>
                      <div className={`w-10 h-10 ${stat.color} rounded-lg flex items-center justify-center`}>
                        <Icon className="h-5 w-5" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* System Overview Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Przegląd systemu</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Nieruchomości</span>
                    <span className="font-medium">{properties.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Najemcy</span>
                    <span className="font-medium">{tenants.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Aktywne umowy</span>
                    <span className="font-medium">{contracts.filter(c => c.status === 'active').length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Ostatni backup</span>
                    <span className="font-medium">Dziś, 03:00</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Aktywność systemu</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Activity className="h-4 w-4 text-green-500" />
                    <span className="text-sm">System działa prawidłowo</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Database className="h-4 w-4 text-blue-500" />
                    <span className="text-sm">Baza danych: Online</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-slate-500" />
                    <span className="text-sm">Uptime: {systemStats.systemUptime}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Shield className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Bezpieczeństwo: OK</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Szybkie akcje</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <Database className="h-4 w-4 mr-2" />
                  Wykonaj backup
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Users className="h-4 w-4 mr-2" />
                  Eksportuj użytkowników
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Activity className="h-4 w-4 mr-2" />
                  Sprawdź logi systemu
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Shield className="h-4 w-4 mr-2" />
                  Ustawienia bezpieczeństwa
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Users Management */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Zarządzanie użytkownikami</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Użytkownik</TableHead>
                      <TableHead>Rola</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ostatnie logowanie</TableHead>
                      <TableHead>Akcje</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockUsers.map((user) => (
                      <TableRow key={user.id} className="hover:bg-slate-50">
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                              <span className="text-primary font-medium text-sm">
                                {getInitials(user.firstName, user.lastName)}
                              </span>
                            </div>
                            <div>
                              <div className="text-sm font-medium text-slate-900">
                                {user.firstName} {user.lastName}
                              </div>
                              <div className="text-sm text-slate-500">{user.email}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          {getRoleBadge(user.role || "user")}
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(true)} {/* Assuming all users are active for demo */}
                        </TableCell>
                        <TableCell className="text-sm text-slate-500">
                          {user.id === "1" ? "Teraz" : "2 dni temu"}
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="ghost">
                              <Shield className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="ghost">
                              <Activity className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* System Logs */}
          <Card>
            <CardHeader>
              <CardTitle>Logi systemowe</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {systemLogs.map((log) => (
                  <div key={log.id} className="flex items-start space-x-4">
                    <div className="mt-2 flex-shrink-0">
                      {getLogIcon(log.type)}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-slate-800">{log.message}</p>
                      <p className="text-xs text-slate-500">{log.details}</p>
                      <p className="text-xs text-slate-400 mt-1">{log.timestamp}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
