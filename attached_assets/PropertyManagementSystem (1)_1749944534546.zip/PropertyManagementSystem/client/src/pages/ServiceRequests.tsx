import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { ServiceRequestForm } from "@/components/ServiceRequestForm";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  Plus, 
  Edit, 
  Trash2, 
  Check, 
  FolderOpen, 
  Wrench, 
  AlertTriangle, 
  Calculator 
} from "lucide-react";
import type { ServiceRequest, ServiceRequestWithRelations, InsertServiceRequest } from "@shared/schema";

export default function ServiceRequests() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingRequest, setEditingRequest] = useState<ServiceRequest | null>(null);
  const [deletingRequest, setDeletingRequest] = useState<ServiceRequest | null>(null);

  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: serviceRequests = [], isLoading, error } = useQuery<ServiceRequestWithRelations[]>({
    queryKey: ["/api/service-requests"],
  });

  // Handle unauthorized errors
  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [error, toast]);

  const createRequestMutation = useMutation({
    mutationFn: async (data: InsertServiceRequest) => {
      await apiRequest("POST", "/api/service-requests", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/service-requests"] });
      setShowAddModal(false);
      toast({
        title: t("saveSuccess"),
        description: "Zgłoszenie serwisowe zostało utworzone pomyślnie",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się utworzyć zgłoszenia serwisowego",
        variant: "destructive",
      });
    },
  });

  const updateRequestMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: InsertServiceRequest }) => {
      await apiRequest("PUT", `/api/service-requests/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/service-requests"] });
      setEditingRequest(null);
      toast({
        title: t("saveSuccess"),
        description: "Zgłoszenie serwisowe zostało zaktualizowane pomyślnie",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się zaktualizować zgłoszenia serwisowego",
        variant: "destructive",
      });
    },
  });

  const deleteRequestMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/service-requests/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/service-requests"] });
      setDeletingRequest(null);
      toast({
        title: t("deleteSuccess"),
        description: "Zgłoszenie serwisowe zostało usunięte pomyślnie",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się usunąć zgłoszenia serwisowego",
        variant: "destructive",
      });
    },
  });

  const completeRequestMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("PUT", `/api/service-requests/${id}`, {
        status: "completed",
        completedAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/service-requests"] });
      toast({
        title: "Sukces",
        description: "Zgłoszenie zostało oznaczone jako zakończone",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się zaktualizować zgłoszenia",
        variant: "destructive",
      });
    },
  });

  const getPriorityBadge = (priority: string) => {
    const priorityMap = {
      low: { label: "Niski", className: "priority-low" },
      medium: { label: "Średni", className: "priority-medium" },
      high: { label: "Wysoki", className: "priority-high" },
      urgent: { label: "Pilny", className: "priority-urgent" },
    };
    
    const priorityInfo = priorityMap[priority as keyof typeof priorityMap] || priorityMap.medium;
    return (
      <Badge className={`status-badge ${priorityInfo.className}`}>
        {priorityInfo.label}
      </Badge>
    );
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      open: { label: "Otwarte", className: "bg-blue-100 text-blue-800" },
      in_progress: { label: "W trakcie", className: "bg-amber-100 text-amber-800" },
      completed: { label: "Zakończone", className: "bg-green-100 text-green-800" },
      cancelled: { label: "Anulowane", className: "bg-gray-100 text-gray-800" },
    };
    
    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.open;
    return (
      <Badge className={`status-badge ${statusInfo.className}`}>
        {statusInfo.label}
      </Badge>
    );
  };

  const getServiceStats = () => {
    const openRequests = serviceRequests.filter(r => r.status === 'open').length;
    const inProgressRequests = serviceRequests.filter(r => r.status === 'in_progress').length;
    const urgentRequests = serviceRequests.filter(r => r.priority === 'urgent').length;
    const averageCost = serviceRequests.length > 0 
      ? serviceRequests
          .filter(r => r.estimatedCost)
          .reduce((sum, r) => sum + parseFloat(r.estimatedCost || "0"), 0) / serviceRequests.filter(r => r.estimatedCost).length
      : 0;

    return [
      { label: "Otwarte zgłoszenia", value: openRequests, icon: FolderOpen, color: "bg-blue-100 text-blue-600" },
      { label: "W trakcie realizacji", value: inProgressRequests, icon: Wrench, color: "bg-amber-100 text-amber-600" },
      { label: "Pilne", value: urgentRequests, icon: AlertTriangle, color: "bg-red-100 text-red-600" },
      { label: "Średni koszt", value: `${averageCost.toLocaleString('pl-PL')} zł`, icon: Calculator, color: "bg-slate-100 text-slate-600" },
    ];
  };

  const formatDate = (dateString: string | Date | null) => {
    if (!dateString) return "Nie określono";
    return new Date(dateString).toLocaleDateString('pl-PL');
  };

  const formatDateTime = (dateString: string | Date | null) => {
    if (!dateString) return "Nie określono";
    return new Date(dateString).toLocaleString('pl-PL');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar
          onSidebarToggle={() => setSidebarOpen(true)}
          title={t("service")}
          description="Zarządzaj naprawami i konserwacją"
        />

        <main className="flex-1 p-6 overflow-auto">
          {/* Header with Add Button */}
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">{t("service")}</h2>
              <p className="text-slate-600">Zarządzaj naprawami i konserwacją</p>
            </div>
            <Button onClick={() => setShowAddModal(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Dodaj zgłoszenie
            </Button>
          </div>

          {/* Service Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            {getServiceStats().map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-slate-500 text-sm font-medium">{stat.label}</p>
                        <p className="text-2xl font-bold text-slate-800">{stat.value}</p>
                      </div>
                      <div className={`w-10 h-10 ${stat.color} rounded-lg flex items-center justify-center`}>
                        <Icon className="h-5 w-5" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Service Requests List */}
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 space-y-3">
                        <div className="flex space-x-2">
                          <div className="h-6 bg-slate-200 rounded w-16" />
                          <div className="h-6 bg-slate-200 rounded w-20" />
                        </div>
                        <div className="h-6 bg-slate-200 rounded w-1/3" />
                        <div className="h-4 bg-slate-200 rounded w-1/2" />
                        <div className="grid grid-cols-4 gap-4">
                          <div className="h-4 bg-slate-200 rounded" />
                          <div className="h-4 bg-slate-200 rounded" />
                          <div className="h-4 bg-slate-200 rounded" />
                          <div className="h-4 bg-slate-200 rounded" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : serviceRequests.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <div className="text-slate-400 mb-4">
                  <Wrench className="w-12 h-12 mx-auto" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">
                  Brak zgłoszeń serwisowych
                </h3>
                <p className="text-slate-500 mb-4">
                  Dodaj pierwsze zgłoszenie serwisowe do systemu.
                </p>
                <Button onClick={() => setShowAddModal(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Dodaj zgłoszenie
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {serviceRequests.map((request) => (
                <Card key={request.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-3">
                          {getPriorityBadge(request.priority || "medium")}
                          {getStatusBadge(request.status || "open")}
                        </div>
                        <h3 className="text-lg font-semibold text-slate-800 mb-2">
                          {request.title}
                        </h3>
                        <p className="text-slate-600 mb-3">
                          {request.description || "Brak opisu"}
                        </p>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="text-slate-500">Nieruchomość</p>
                            <p className="font-medium text-slate-800">
                              {request.property?.address || "Nieznana"}
                            </p>
                          </div>
                          <div>
                            <p className="text-slate-500">Zgłaszający</p>
                            <p className="font-medium text-slate-800">
                              {request.tenant 
                                ? `${request.tenant.firstName} ${request.tenant.lastName}`
                                : "Właściciel"
                              }
                            </p>
                          </div>
                          <div>
                            <p className="text-slate-500">Szacowany koszt</p>
                            <p className="font-medium text-slate-800">
                              {request.estimatedCost 
                                ? `${parseFloat(request.estimatedCost).toLocaleString('pl-PL')} zł`
                                : "Nie określono"
                              }
                            </p>
                          </div>
                          <div>
                            <p className="text-slate-500">Termin realizacji</p>
                            <p className="font-medium text-slate-800">
                              {formatDate(request.dueDate)}
                            </p>
                          </div>
                        </div>

                        {request.assignedTo && (
                          <div className="mt-3 text-sm">
                            <span className="text-slate-500">Przypisane do: </span>
                            <span className="font-medium text-slate-800">{request.assignedTo}</span>
                          </div>
                        )}

                        {request.completedAt && (
                          <div className="mt-3 text-sm">
                            <span className="text-slate-500">Zakończone: </span>
                            <span className="font-medium text-slate-800">{formatDateTime(request.completedAt)}</span>
                          </div>
                        )}
                      </div>
                      <div className="flex space-x-2 ml-4">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setEditingRequest(request)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        {request.status !== 'completed' && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => completeRequestMutation.mutate(request.id)}
                            disabled={completeRequestMutation.isPending}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setDeletingRequest(request)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </main>
      </div>

      {/* Add Service Request Modal */}
      <Dialog open={showAddModal} onOpenChange={setShowAddModal}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Dodaj nowe zgłoszenie serwisowe</DialogTitle>
          </DialogHeader>
          <ServiceRequestForm
            onSubmit={(data) => createRequestMutation.mutate(data)}
            onCancel={() => setShowAddModal(false)}
            isLoading={createRequestMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Service Request Modal */}
      <Dialog open={!!editingRequest} onOpenChange={() => setEditingRequest(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edytuj zgłoszenie serwisowe</DialogTitle>
          </DialogHeader>
          {editingRequest && (
            <ServiceRequestForm
              serviceRequest={editingRequest}
              onSubmit={(data) => 
                updateRequestMutation.mutate({ id: editingRequest.id, data })
              }
              onCancel={() => setEditingRequest(null)}
              isLoading={updateRequestMutation.isPending}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deletingRequest} onOpenChange={() => setDeletingRequest(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Potwierdź usunięcie</AlertDialogTitle>
            <AlertDialogDescription>
              Czy na pewno chcesz usunąć zgłoszenie serwisowe "{deletingRequest?.title}"? 
              Ta operacja nie może zostać cofnięta.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Anuluj</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingRequest && deleteRequestMutation.mutate(deletingRequest.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Usuń
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
