import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  Building,
  FileText,
  TrendingUp,
  Clock,
  Plus,
  UserPlus,
  FileSignature,
  Download,
  ArrowUp,
} from "lucide-react";

interface DashboardStats {
  totalProperties: number;
  activeContracts: number;
  monthlyRevenue: number;
  pendingPayments: number;
}

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { t } = useLanguage();

  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('pl-PL', {
      style: 'currency',
      currency: 'PLN',
    }).format(amount);
  };

  const statsCards = [
    {
      title: t("totalProperties"),
      value: stats?.totalProperties || 0,
      icon: Building,
      color: "bg-blue-500",
      change: "+12%",
      changeColor: "text-green-600",
    },
    {
      title: t("activeContracts"),
      value: stats?.activeContracts || 0,
      icon: FileText,
      color: "bg-green-500",
      change: "+8%",
      changeColor: "text-green-600",
    },
    {
      title: t("monthlyRevenue"),
      value: formatCurrency(stats?.monthlyRevenue || 0),
      icon: TrendingUp,
      color: "bg-emerald-500",
      change: "+15%",
      changeColor: "text-green-600",
    },
    {
      title: t("pendingPayments"),
      value: formatCurrency(stats?.pendingPayments || 0),
      icon: Clock,
      color: "bg-amber-500",
      change: "+5%",
      changeColor: "text-red-600",
    },
  ];

  const recentActivities = [
    {
      id: 1,
      type: "contract",
      title: "Nowa umowa najmu podpisana",
      description: "Apartament przy ul. Mickiewicza 15 - Jan Kowalski",
      time: "2 godziny temu",
      icon: Plus,
      color: "bg-blue-100 text-blue-600",
    },
    {
      id: 2,
      type: "payment",
      title: "Płatność otrzymana",
      description: "Czynsz - Dom przy ul. Słowackiego 8",
      time: "5 godzin temu",
      icon: TrendingUp,
      color: "bg-green-100 text-green-600",
    },
    {
      id: 3,
      type: "service",
      title: "Nowe zgłoszenie serwisowe",
      description: "Awaria instalacji - Studio przy ul. Kwiatowej 3",
      time: "1 dzień temu",
      icon: Clock,
      color: "bg-amber-100 text-amber-600",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar
          onSidebarToggle={() => setSidebarOpen(true)}
          title={t("dashboard")}
          description="Przegląd systemu zarządzania nieruchomościami"
        />

        <main className="flex-1 p-6 overflow-auto">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {statsCards.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-slate-500 text-sm font-medium mb-1">
                          {stat.title}
                        </p>
                        <p className="text-3xl font-bold text-slate-800">
                          {isLoading ? "..." : stat.value}
                        </p>
                      </div>
                      <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                    </div>
                    <div className="mt-4 flex items-center">
                      <ArrowUp className={`h-4 w-4 ${stat.changeColor} mr-1`} />
                      <span className={`text-sm font-medium ${stat.changeColor}`}>
                        {stat.change}
                      </span>
                      <span className="text-slate-500 text-sm ml-2">
                        vs poprzedni miesiąc
                      </span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Recent Activity & Quick Actions */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent Activity */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>{t("recentActivity")}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivities.map((activity) => {
                      const Icon = activity.icon;
                      return (
                        <div key={activity.id} className="flex items-start space-x-4">
                          <div className={`w-8 h-8 ${activity.color} rounded-full flex items-center justify-center flex-shrink-0`}>
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-slate-800">
                              {activity.title}
                            </p>
                            <p className="text-xs text-slate-500">
                              {activity.description}
                            </p>
                            <p className="text-xs text-slate-400 mt-1">
                              {activity.time}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>{t("quickActions")}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full justify-start" variant="default">
                    <Plus className="h-4 w-4 mr-2" />
                    {t("addProperty")}
                  </Button>
                  <Button className="w-full justify-start" variant="outline">
                    <UserPlus className="h-4 w-4 mr-2" />
                    {t("addTenant")}
                  </Button>
                  <Button className="w-full justify-start" variant="outline">
                    <FileSignature className="h-4 w-4 mr-2" />
                    {t("createContract")}
                  </Button>
                  <Button className="w-full justify-start" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    {t("downloadReport")}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
