import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { SimpleContractForm } from "@/components/SimpleContractForm";
import { BulkOperations } from "@/components/BulkOperations";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Plus, Edit, Download, FileText, Check, Clock, AlertTriangle, X } from "lucide-react";
import type { Contract, ContractWithRelations, InsertContract } from "@shared/schema";

export default function Contracts() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingContract, setEditingContract] = useState<Contract | null>(null);
  const [statusFilter, setStatusFilter] = useState("");

  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: contracts = [], isLoading, error } = useQuery<ContractWithRelations[]>({
    queryKey: ["/api/contracts"],
  });

  // Handle unauthorized errors
  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [error, toast]);

  const createContractMutation = useMutation({
    mutationFn: async (data: InsertContract) => {
      await apiRequest("POST", "/api/contracts", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/properties"] });
      setShowAddModal(false);
      toast({
        title: t("saveSuccess"),
        description: "Umowa została utworzona pomyślnie",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się utworzyć umowy",
        variant: "destructive",
      });
    },
  });

  const updateContractMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: InsertContract }) => {
      await apiRequest("PUT", `/api/contracts/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      setEditingContract(null);
      toast({
        title: t("saveSuccess"),
        description: "Umowa została zaktualizowana pomyślnie",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: t("error"),
        description: "Nie udało się zaktualizować umowy",
        variant: "destructive",
      });
    },
  });

  const getStatusBadge = (status: string, endDate: string) => {
    const today = new Date();
    const contractEnd = new Date(endDate);
    const daysUntilExpiry = Math.ceil((contractEnd.getTime() - today.getTime()) / (1000 * 3600 * 24));

    if (status === "active") {
      if (daysUntilExpiry <= 30 && daysUntilExpiry > 0) {
        return (
          <Badge className="status-badge bg-amber-100 text-amber-800">
            Wygasa za {daysUntilExpiry} dni
          </Badge>
        );
      } else if (daysUntilExpiry <= 0) {
        return (
          <Badge className="status-badge bg-red-100 text-red-800">
            Wygasła
          </Badge>
        );
      }
      return (
        <Badge className="status-badge status-rented">
          Aktywna
        </Badge>
      );
    }

    const statusMap = {
      expired: { label: "Wygasła", className: "bg-red-100 text-red-800" },
      terminated: { label: "Rozwiązana", className: "bg-gray-100 text-gray-800" },
    };

    const statusInfo = statusMap[status as keyof typeof statusMap];
    if (statusInfo) {
      return (
        <Badge className={`status-badge ${statusInfo.className}`}>
          {statusInfo.label}
        </Badge>
      );
    }

    return (
      <Badge className="status-badge status-available">
        {status}
      </Badge>
    );
  };

  const getStatsCards = () => {
    const activeContracts = contracts.filter(c => c.status === 'active').length;
    const expiringContracts = contracts.filter(c => {
      if (c.status !== 'active') return false;
      const today = new Date();
      const contractEnd = new Date(c.endDate);
      const daysUntilExpiry = Math.ceil((contractEnd.getTime() - today.getTime()) / (1000 * 3600 * 24));
      return daysUntilExpiry <= 30 && daysUntilExpiry > 0;
    }).length;
    const expiredContracts = contracts.filter(c => c.status === 'expired').length;
    const terminatedContracts = contracts.filter(c => c.status === 'terminated').length;

    return [
      { label: "Aktywne", value: activeContracts, icon: Check, color: "bg-green-100 text-green-600" },
      { label: "Wygasające", value: expiringContracts, icon: Clock, color: "bg-amber-100 text-amber-600" },
      { label: "Wygasłe", value: expiredContracts, icon: AlertTriangle, color: "bg-red-100 text-red-600" },
      { label: "Rozwiązane", value: terminatedContracts, icon: X, color: "bg-gray-100 text-gray-600" },
    ];
  };

  const filteredContracts = contracts.filter(contract => 
    !statusFilter || contract.status === statusFilter
  );

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar
          onSidebarToggle={() => setSidebarOpen(true)}
          title={t("contracts")}
          description="Zarządzaj umowami najmu"
        />

        <main className="flex-1 p-6 overflow-auto">
          {/* Header with Add Button */}
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">{t("contracts")}</h2>
              <p className="text-slate-600">Zarządzaj umowami najmu</p>
            </div>
            <Button onClick={() => setShowAddModal(true)}>
              <Plus className="h-4 w-4 mr-2" />
              {t("createContract")}
            </Button>
          </div>

          {/* Contract Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            {getStatsCards().map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex items-center">
                      <div className={`w-8 h-8 ${stat.color} rounded-lg flex items-center justify-center`}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-slate-600">{stat.label}</p>
                        <p className="text-xl font-bold text-slate-800">{stat.value}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Contracts List */}
          <Card>
            <CardContent className="p-0">
              <div className="px-6 py-4 border-b border-slate-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-slate-800">Lista umów</h3>
                  <div className="flex items-center space-x-2">
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Wszystkie statusy" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Wszystkie statusy</SelectItem>
                        <SelectItem value="active">Aktywne</SelectItem>
                        <SelectItem value="expired">Wygasłe</SelectItem>
                        <SelectItem value="terminated">Rozwiązane</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Excel
                    </Button>
                  </div>
                </div>
              </div>

              {isLoading ? (
                <div className="p-8">
                  <div className="animate-pulse space-y-4">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="flex items-center space-x-4 p-4">
                        <div className="w-12 h-12 bg-slate-200 rounded-lg" />
                        <div className="flex-1 space-y-2">
                          <div className="h-4 bg-slate-200 rounded w-1/3" />
                          <div className="h-3 bg-slate-200 rounded w-1/2" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : filteredContracts.length === 0 ? (
                <div className="p-12 text-center">
                  <div className="text-slate-400 mb-4">
                    <FileText className="w-12 h-12 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-slate-900 mb-2">
                    Brak umów
                  </h3>
                  <p className="text-slate-500 mb-4">
                    {statusFilter ? "Nie znaleziono umów o wybranym statusie." : "Dodaj pierwszą umowę najmu."}
                  </p>
                  <Button onClick={() => setShowAddModal(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Utwórz umowę
                  </Button>
                </div>
              ) : (
                <div className="divide-y divide-slate-200">
                  {filteredContracts.map((contract) => (
                    <div key={contract.id} className="p-6 hover:bg-slate-50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                              <FileText className="h-6 w-6 text-primary" />
                            </div>
                            <div>
                              <h4 className="text-lg font-semibold text-slate-800">
                                {contract.property?.address || "Nieznana nieruchomość"}
                              </h4>
                              <p className="text-slate-600">
                                {contract.tenant?.firstName} {contract.tenant?.lastName}
                              </p>
                              <div className="flex items-center space-x-4 mt-2">
                                <span className="text-sm text-slate-500">
                                  Od: {new Date(contract.startDate).toLocaleDateString('pl-PL')}
                                </span>
                                <span className="text-sm text-slate-500">
                                  Do: {new Date(contract.endDate).toLocaleDateString('pl-PL')}
                                </span>
                                <span className="text-sm font-medium text-slate-800">
                                  {parseFloat(contract.monthlyRent).toLocaleString('pl-PL')} zł/mies.
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          {getStatusBadge(contract.status || "active", contract.endDate)}
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setEditingContract(contract)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="ghost">
                              <Download className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      {/* Add Contract Modal */}
      <Dialog open={showAddModal} onOpenChange={setShowAddModal}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Utwórz nową umowę najmu</DialogTitle>
          </DialogHeader>
          <ContractForm
            onSubmit={(data) => createContractMutation.mutate(data)}
            onCancel={() => setShowAddModal(false)}
            isLoading={createContractMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Contract Modal */}
      <Dialog open={!!editingContract} onOpenChange={() => setEditingContract(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edytuj umowę najmu</DialogTitle>
          </DialogHeader>
          {editingContract && (
            <ContractForm
              contract={editingContract}
              onSubmit={(data) => 
                updateContractMutation.mutate({ id: editingContract.id, data })
              }
              onCancel={() => setEditingContract(null)}
              isLoading={updateContractMutation.isPending}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
