import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Building, Users, FileText, CreditCard, Wrench, BarChart } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-primary/5">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-primary rounded-lg flex items-center justify-center">
              <Building className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-5xl font-bold text-slate-800 mb-4">
            RentalMaster
          </h1>
          <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
            Kompleksowy system zarządzania nieruchomościami. Zarządzaj własnościami, 
            najemcami, umowami i płatnościami w jednym miejscu.
          </p>
          <Button onClick={handleLogin} size="lg" className="text-lg px-8 py-3">
            Zaloguj się do systemu
          </Button>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <Card className="text-center">
            <CardHeader>
              <Building className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Zarządzanie nieruchomościami</CardTitle>
              <CardDescription>
                Kompleksowe zarządzanie własnościami z automatyczną zmianą statusów
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Users className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Baza najemców</CardTitle>
              <CardDescription>
                Pełna baza danych najemców z kontaktami awaryję i historiami
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <FileText className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>System umów</CardTitle>
              <CardDescription>
                Automatyczne łączenie najemców z nieruchomościami i śledzenie terminów
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <CreditCard className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Płatności i faktury</CardTitle>
              <CardDescription>
                Śledzenie płatności, generowanie faktur i eksport do Excel
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Wrench className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Zgłoszenia serwisowe</CardTitle>
              <CardDescription>
                Kompletny system zarządzania naprawami z priorytetami i kosztami
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <BarChart className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Raporty i analityka</CardTitle>
              <CardDescription>
                Zaawansowane raporty finansowe i analiza rentowności
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* Demo Info */}
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="text-center">Demo System</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-slate-600 mb-4">
              Aby przetestować system, użyj danych logowania:
            </p>
            <div className="bg-slate-100 rounded-lg p-4 mb-4">
              <p className="font-medium">Nazwa użytkownika: <strong>admin</strong></p>
              <p className="font-medium">Hasło: <strong>admin</strong></p>
            </div>
            <Button onClick={handleLogin} className="w-full">
              Przejdź do logowania
            </Button>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-16 text-slate-500">
          <p>© 2024 RentalMaster - Kompletne rozwiązanie do zarządzania nieruchomościami</p>
        </div>
      </div>
    </div>
  );
}
