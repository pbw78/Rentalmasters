import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Download, TrendingUp, Building, Users, DollarSign } from "lucide-react";
import type { 
  PropertyWithRelations, 
  TenantWithRelations, 
  ContractWithRelations, 
  ServiceRequestWithRelations,
  PaymentWithRelations 
} from "@shared/schema";

interface DashboardStats {
  totalProperties: number;
  activeContracts: number;
  monthlyRevenue: number;
  pendingPayments: number;
}

export default function Reports() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [timePeriod, setTimePeriod] = useState("month");

  const { t } = useLanguage();
  const { toast } = useToast();

  const { data: properties = [], error: propertiesError } = useQuery<PropertyWithRelations[]>({
    queryKey: ["/api/properties"],
  });

  const { data: tenants = [], error: tenantsError } = useQuery<TenantWithRelations[]>({
    queryKey: ["/api/tenants"],
  });

  const { data: contracts = [], error: contractsError } = useQuery<ContractWithRelations[]>({
    queryKey: ["/api/contracts"],
  });

  const { data: serviceRequests = [], error: serviceError } = useQuery<ServiceRequestWithRelations[]>({
    queryKey: ["/api/service-requests"],
  });

  const { data: payments = [], error: paymentsError } = useQuery<PaymentWithRelations[]>({
    queryKey: ["/api/payments"],
  });

  const { data: stats, error: statsError } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  // Handle unauthorized errors
  useEffect(() => {
    const errors = [propertiesError, tenantsError, contractsError, serviceError, paymentsError, statsError];
    const unauthorizedError = errors.find(error => error && isUnauthorizedError(error as Error));
    
    if (unauthorizedError) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [propertiesError, tenantsError, contractsError, serviceError, paymentsError, statsError, toast]);

  const handleExport = () => {
    const data = {
      properties: properties.length,
      tenants: tenants.length,
      contracts: contracts.length,
      serviceRequests: serviceRequests.length,
      payments: payments.length,
      stats,
      period: timePeriod,
      exportDate: new Date().toISOString(),
    };

    const jsonString = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `rental-master-report-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "Eksport zakończony",
      description: "Raport został pobrany pomyślnie",
    });
  };

  const getMonthlyRevenue = () => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    return payments
      .filter(p => {
        if (!p.paidDate || p.status !== 'paid') return false;
        const paidDate = new Date(p.paidDate);
        return paidDate.getMonth() === currentMonth && paidDate.getFullYear() === currentYear;
      })
      .reduce((sum, p) => sum + parseFloat(p.amount), 0);
  };

  const getOccupancyRate = () => {
    if (properties.length === 0) return 0;
    const rentedProperties = properties.filter(p => p.status === 'rented').length;
    return Math.round((rentedProperties / properties.length) * 100);
  };

  const getTopTenants = () => {
    return contracts
      .filter(c => c.status === 'active')
      .sort((a, b) => parseFloat(b.monthlyRent) - parseFloat(a.monthlyRent))
      .slice(0, 3)
      .map(contract => ({
        name: `${contract.tenant?.firstName} ${contract.tenant?.lastName}`,
        property: contract.property?.address,
        rent: parseFloat(contract.monthlyRent),
      }));
  };

  const getServiceCosts = () => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const thisMonthRequests = serviceRequests.filter(r => {
      if (!r.createdAt) return false;
      const createdDate = new Date(r.createdAt);
      return createdDate.getMonth() === currentMonth && createdDate.getFullYear() === currentYear;
    });

    const totalCost = thisMonthRequests.reduce((sum, r) => {
      const cost = r.actualCost || r.estimatedCost || "0";
      return sum + parseFloat(cost);
    }, 0);

    const repairs = thisMonthRequests.filter(r => r.priority === 'urgent' || r.priority === 'high').length;
    const maintenance = thisMonthRequests.filter(r => r.priority === 'medium').length;
    const improvements = thisMonthRequests.filter(r => r.priority === 'low').length;

    return {
      total: totalCost,
      breakdown: [
        { label: "Naprawy", value: repairs * 200 }, // Rough estimate
        { label: "Konserwacja", value: maintenance * 100 },
        { label: "Modernizacja", value: improvements * 150 },
      ]
    };
  };

  const getPerformanceMetrics = () => {
    const totalPayments = payments.length;
    const paidOnTime = payments.filter(p => {
      if (p.status !== 'paid' || !p.paidDate) return false;
      return new Date(p.paidDate) <= new Date(p.dueDate);
    }).length;

    const paymentTimeliness = totalPayments > 0 ? Math.round((paidOnTime / totalPayments) * 100) : 0;

    const completedRequests = serviceRequests.filter(r => r.status === 'completed').length;
    const totalRequests = serviceRequests.length;
    const serviceEfficiency = totalRequests > 0 ? Math.round((completedRequests / totalRequests) * 100) : 0;

    const activeTenants = tenants.filter(t => t.isActive).length;
    const tenantSatisfaction = 92; // Mock value - in real app would come from surveys

    return {
      paymentTimeliness,
      serviceEfficiency,
      tenantSatisfaction,
    };
  };

  const monthlyRevenue = getMonthlyRevenue();
  const occupancyRate = getOccupancyRate();
  const topTenants = getTopTenants();
  const serviceCosts = getServiceCosts();
  const performanceMetrics = getPerformanceMetrics();

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar
          onSidebarToggle={() => setSidebarOpen(true)}
          title={t("reports")}
          description="Przegląd wyników i analiz"
        />

        <main className="flex-1 p-6 overflow-auto">
          {/* Header with Export */}
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">{t("reports")}</h2>
              <p className="text-slate-600">Przegląd wyników i analiz</p>
            </div>
            <div className="flex space-x-3">
              <Select value={timePeriod} onValueChange={setTimePeriod}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="month">Ostatni miesiąc</SelectItem>
                  <SelectItem value="quarter">Ostatnie 3 miesiące</SelectItem>
                  <SelectItem value="year">Ostatni rok</SelectItem>
                  <SelectItem value="all">Wszystkie dane</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={handleExport}>
                <Download className="h-4 w-4 mr-2" />
                Eksportuj raport
              </Button>
            </div>
          </div>

          {/* Financial Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5" />
                  <span>Przychody miesięczne</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Styczeń 2024</span>
                    <span className="font-semibold text-slate-800">
                      {monthlyRevenue.toLocaleString('pl-PL')} zł
                    </span>
                  </div>
                  <Progress value={85} className="h-2" />
                  
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Grudzień 2023</span>
                    <span className="font-semibold text-slate-800">
                      {(monthlyRevenue * 0.94).toLocaleString('pl-PL')} zł
                    </span>
                  </div>
                  <Progress value={80} className="h-2" />
                  
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Listopad 2023</span>
                    <span className="font-semibold text-slate-800">
                      {(monthlyRevenue * 0.97).toLocaleString('pl-PL')} zł
                    </span>
                  </div>
                  <Progress value={82} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Building className="h-5 w-5" />
                  <span>Obłożenie nieruchomości</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-4">
                  <div className="text-4xl font-bold text-primary">{occupancyRate}%</div>
                  <p className="text-slate-600">Średnie obłożenie</p>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Wynajęte</span>
                    <span className="font-semibold text-green-600">
                      {properties.filter(p => p.status === 'rented').length} lokali
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Dostępne</span>
                    <span className="font-semibold text-blue-600">
                      {properties.filter(p => p.status === 'available').length} lokale
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">W remoncie</span>
                    <span className="font-semibold text-amber-600">
                      {properties.filter(p => p.status === 'maintenance').length} lokale
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Reports */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-5 w-5" />
                  <span>Top najemcy</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {topTenants.map((tenant, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-primary font-medium text-sm">
                            {tenant.name.split(' ').map(n => n.charAt(0)).join('')}
                          </span>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-800">{tenant.name}</p>
                          <p className="text-xs text-slate-500">{tenant.property}</p>
                        </div>
                      </div>
                      <span className="text-sm font-semibold text-green-600">
                        {tenant.rent.toLocaleString('pl-PL')} zł
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <DollarSign className="h-5 w-5" />
                  <span>Koszty serwisu</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-4">
                  <div className="text-2xl font-bold text-red-600">
                    {serviceCosts.total.toLocaleString('pl-PL')} zł
                  </div>
                  <p className="text-slate-600 text-sm">w tym miesiącu</p>
                </div>
                <div className="space-y-2">
                  {serviceCosts.breakdown.map((item, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span className="text-slate-600">{item.label}</span>
                      <span className="font-medium">{item.value.toLocaleString('pl-PL')} zł</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Wskaźniki wydajności</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-slate-600">Terminowość płatności</span>
                      <span className="font-medium">{performanceMetrics.paymentTimeliness}%</span>
                    </div>
                    <Progress value={performanceMetrics.paymentTimeliness} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-slate-600">Sprawność serwisu</span>
                      <span className="font-medium">{performanceMetrics.serviceEfficiency}%</span>
                    </div>
                    <Progress value={performanceMetrics.serviceEfficiency} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-slate-600">Satysfakcja najemców</span>
                      <span className="font-medium">{performanceMetrics.tenantSatisfaction}%</span>
                    </div>
                    <Progress value={performanceMetrics.tenantSatisfaction} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Summary Stats */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-slate-800">{properties.length}</div>
                <p className="text-slate-600">Łączne nieruchomości</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-slate-800">{contracts.filter(c => c.status === 'active').length}</div>
                <p className="text-slate-600">Aktywne umowy</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-slate-800">{tenants.filter(t => t.isActive).length}</div>
                <p className="text-slate-600">Aktywni najemcy</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-slate-800">{serviceRequests.filter(r => r.status === 'open').length}</div>
                <p className="text-slate-600">Otwarte zgłoszenia</p>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
