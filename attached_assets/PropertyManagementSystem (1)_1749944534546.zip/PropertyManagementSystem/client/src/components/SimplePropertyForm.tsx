import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPropertySchema, type InsertProperty, type Property } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { Building2 } from "lucide-react";

interface SimplePropertyFormProps {
  property?: Property;
  onSubmit: (data: InsertProperty) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function SimplePropertyForm({ property, onSubmit, onCancel, isLoading }: SimplePropertyFormProps) {
  const { t } = useLanguage();
  
  const form = useForm<InsertProperty>({
    resolver: zodResolver(insertPropertySchema),
    defaultValues: {
      address: property?.address || "",
      type: property?.type || "apartment",
      area: property?.area || "",
      rooms: property?.rooms || 1,
      bathrooms: property?.bathrooms || 1,
      monthlyRent: property?.monthlyRent || "",
      deposit: property?.deposit || "",
      status: property?.status || "available",
      description: property?.description || "",
    },
  });

  const handleSubmit = (data: InsertProperty) => {
    onSubmit(data);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building2 className="h-5 w-5" />
          {property ? "Edytuj nieruchomość" : "Dodaj nieruchomość"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="address">Adres *</Label>
            <Input
              id="address"
              {...form.register("address")}
              placeholder="ul. Przykładowa 123, Warszawa"
            />
            {form.formState.errors.address && (
              <p className="text-sm text-red-600">{form.formState.errors.address.message}</p>
            )}
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="type">Typ nieruchomości *</Label>
              <Select value={form.watch("type")} onValueChange={(value) => form.setValue("type", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Wybierz typ" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="apartment">Mieszkanie</SelectItem>
                  <SelectItem value="house">Dom</SelectItem>
                  <SelectItem value="studio">Kawalerka</SelectItem>
                  <SelectItem value="commercial">Komercyjne</SelectItem>
                  <SelectItem value="office">Biuro</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="area">Powierzchnia (m²)</Label>
              <Input
                id="area"
                {...form.register("area")}
                placeholder="50"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="rooms">Pokoje</Label>
              <Input
                id="rooms"
                type="number"
                min="0"
                {...form.register("rooms", { valueAsNumber: true })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bathrooms">Łazienki</Label>
              <Input
                id="bathrooms"
                type="number"
                min="0"
                {...form.register("bathrooms", { valueAsNumber: true })}
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="monthlyRent">Czynsz miesięczny (PLN) *</Label>
              <Input
                id="monthlyRent"
                {...form.register("monthlyRent")}
                placeholder="2500.00"
              />
              {form.formState.errors.monthlyRent && (
                <p className="text-sm text-red-600">{form.formState.errors.monthlyRent.message}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="deposit">Kaucja (PLN)</Label>
              <Input
                id="deposit"
                {...form.register("deposit")}
                placeholder="5000.00"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
            <Select value={form.watch("status") || "available"} onValueChange={(value) => form.setValue("status", value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="available">Dostępne</SelectItem>
                <SelectItem value="rented">Wynajęte</SelectItem>
                <SelectItem value="maintenance">W remoncie</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Opis</Label>
            <Textarea
              id="description"
              {...form.register("description")}
              placeholder="Opisz nieruchomość..."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Anuluj
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Zapisywanie..." : property ? "Aktualizuj" : "Utwórz"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}