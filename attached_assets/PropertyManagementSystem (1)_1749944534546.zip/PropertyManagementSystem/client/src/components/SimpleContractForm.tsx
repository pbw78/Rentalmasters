import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContractSchema, type InsertContract, type Contract } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { FileText } from "lucide-react";

interface SimpleContractFormProps {
  contract?: Contract;
  onSubmit: (data: InsertContract) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function SimpleContractForm({ contract, onSubmit, onCancel, isLoading }: SimpleContractFormProps) {
  const { t } = useLanguage();
  
  const { data: properties = [] } = useQuery({
    queryKey: ["/api/properties"],
  });

  const { data: tenants = [] } = useQuery({
    queryKey: ["/api/tenants"],
  });
  
  const form = useForm<InsertContract>({
    resolver: zodResolver(insertContractSchema),
    defaultValues: {
      propertyId: contract?.propertyId || undefined,
      tenantId: contract?.tenantId || undefined,
      startDate: contract?.startDate ? new Date(contract.startDate).toISOString().split('T')[0] : "",
      endDate: contract?.endDate ? new Date(contract.endDate).toISOString().split('T')[0] : "",
      monthlyRent: contract?.monthlyRent || "",
      deposit: contract?.deposit || "",
      status: contract?.status || "active",
    },
  });

  const handleSubmit = (data: InsertContract) => {
    onSubmit(data);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          {contract ? "Edytuj umowę" : "Dodaj umowę"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="propertyId">Nieruchomość *</Label>
              <Select 
                value={form.watch("propertyId")?.toString()} 
                onValueChange={(value) => form.setValue("propertyId", parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Wybierz nieruchomość" />
                </SelectTrigger>
                <SelectContent>
                  {properties.map((property: any) => (
                    <SelectItem key={property.id} value={property.id.toString()}>
                      {property.address}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.propertyId && (
                <p className="text-sm text-red-600">{form.formState.errors.propertyId.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="tenantId">Najemca *</Label>
              <Select 
                value={form.watch("tenantId")?.toString()} 
                onValueChange={(value) => form.setValue("tenantId", parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Wybierz najemcę" />
                </SelectTrigger>
                <SelectContent>
                  {tenants.map((tenant: any) => (
                    <SelectItem key={tenant.id} value={tenant.id.toString()}>
                      {tenant.firstName} {tenant.lastName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.tenantId && (
                <p className="text-sm text-red-600">{form.formState.errors.tenantId.message}</p>
              )}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate">Data rozpoczęcia *</Label>
              <Input
                id="startDate"
                type="date"
                {...form.register("startDate")}
              />
              {form.formState.errors.startDate && (
                <p className="text-sm text-red-600">{form.formState.errors.startDate.message}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="endDate">Data zakończenia *</Label>
              <Input
                id="endDate"
                type="date"
                {...form.register("endDate")}
              />
              {form.formState.errors.endDate && (
                <p className="text-sm text-red-600">{form.formState.errors.endDate.message}</p>
              )}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="monthlyRent">Czynsz miesięczny (PLN) *</Label>
              <Input
                id="monthlyRent"
                {...form.register("monthlyRent")}
                placeholder="2500.00"
              />
              {form.formState.errors.monthlyRent && (
                <p className="text-sm text-red-600">{form.formState.errors.monthlyRent.message}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="deposit">Kaucja (PLN)</Label>
              <Input
                id="deposit"
                {...form.register("deposit")}
                placeholder="5000.00"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
            <Select 
              value={form.watch("status") || "active"} 
              onValueChange={(value) => form.setValue("status", value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Aktywna</SelectItem>
                <SelectItem value="expired">Wygasła</SelectItem>
                <SelectItem value="terminated">Rozwiązana</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Anuluj
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Zapisywanie..." : contract ? "Aktualizuj" : "Utwórz"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}