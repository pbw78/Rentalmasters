import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPaymentSchema, type InsertPayment, type Payment } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { CreditCard } from "lucide-react";

interface SimplePaymentFormProps {
  payment?: Payment;
  onSubmit: (data: InsertPayment) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function SimplePaymentForm({ payment, onSubmit, onCancel, isLoading }: SimplePaymentFormProps) {
  const { t } = useLanguage();
  
  const { data: contracts = [] } = useQuery({
    queryKey: ["/api/contracts"],
  });
  
  const form = useForm<InsertPayment>({
    resolver: zodResolver(insertPaymentSchema),
    defaultValues: {
      contractId: payment?.contractId || undefined,
      amount: payment?.amount || "",
      dueDate: payment?.dueDate ? new Date(payment.dueDate).toISOString().split('T')[0] : "",
      paidDate: payment?.paidDate ? new Date(payment.paidDate).toISOString().split('T')[0] : "",
      status: payment?.status || "pending",
      paymentMethod: payment?.paymentMethod || "",
    },
  });

  const handleSubmit = (data: InsertPayment) => {
    onSubmit(data);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="h-5 w-5" />
          {payment ? "Edytuj płatność" : "Dodaj płatność"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="contractId">Umowa *</Label>
            <Select 
              value={form.watch("contractId")?.toString()} 
              onValueChange={(value) => form.setValue("contractId", parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Wybierz umowę" />
              </SelectTrigger>
              <SelectContent>
                {contracts.map((contract: any) => (
                  <SelectItem key={contract.id} value={contract.id.toString()}>
                    {contract.property?.address} - {contract.tenant?.firstName} {contract.tenant?.lastName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.contractId && (
              <p className="text-sm text-red-600">{form.formState.errors.contractId.message}</p>
            )}
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Kwota (PLN) *</Label>
              <Input
                id="amount"
                {...form.register("amount")}
                placeholder="2500.00"
              />
              {form.formState.errors.amount && (
                <p className="text-sm text-red-600">{form.formState.errors.amount.message}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDate">Termin płatności *</Label>
              <Input
                id="dueDate"
                type="date"
                {...form.register("dueDate")}
              />
              {form.formState.errors.dueDate && (
                <p className="text-sm text-red-600">{form.formState.errors.dueDate.message}</p>
              )}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="paidDate">Data płatności</Label>
              <Input
                id="paidDate"
                type="date"
                {...form.register("paidDate")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="paymentMethod">Sposób płatności</Label>
              <Select 
                value={form.watch("paymentMethod") || ""} 
                onValueChange={(value) => form.setValue("paymentMethod", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Wybierz sposób płatności" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="transfer">Przelew</SelectItem>
                  <SelectItem value="cash">Gotówka</SelectItem>
                  <SelectItem value="card">Karta</SelectItem>
                  <SelectItem value="check">Czek</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
            <Select 
              value={form.watch("status") || "pending"} 
              onValueChange={(value) => form.setValue("status", value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Oczekująca</SelectItem>
                <SelectItem value="paid">Opłacona</SelectItem>
                <SelectItem value="overdue">Zaległa</SelectItem>
                <SelectItem value="cancelled">Anulowana</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Anuluj
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Zapisywanie..." : payment ? "Aktualizuj" : "Utwórz"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}