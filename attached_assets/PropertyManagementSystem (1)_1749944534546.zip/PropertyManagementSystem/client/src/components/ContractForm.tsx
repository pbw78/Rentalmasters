import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useLanguage } from "@/contexts/LanguageContext";
import { useQuery } from "@tanstack/react-query";
import type { Contract, InsertContract, Property, Tenant } from "@shared/schema";

const contractFormSchema = z.object({
  propertyId: z.string().min(1, "Nieruchomość jest wymagana"),
  tenantId: z.string().min(1, "Najemca jest wymagany"),
  startDate: z.string().min(1, "Data rozpoczęcia jest wymagana"),
  endDate: z.string().min(1, "Data zakończenia jest wymagana"),
  monthlyRent: z.string().min(1, "Czynsz miesięczny jest wymagany"),
  deposit: z.string().optional(),
  paymentDay: z.string().optional(),
  terms: z.string().optional(),
  status: z.string().default("active"),
});

interface ContractFormProps {
  contract?: Contract;
  onSubmit: (data: InsertContract) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function ContractForm({ contract, onSubmit, onCancel, isLoading }: ContractFormProps) {
  const { t } = useLanguage();

  const { data: properties = [] } = useQuery<Property[]>({
    queryKey: ["/api/properties"],
  });

  const { data: tenants = [] } = useQuery<Tenant[]>({
    queryKey: ["/api/tenants"],
  });

  const form = useForm<z.infer<typeof contractFormSchema>>({
    resolver: zodResolver(contractFormSchema),
    defaultValues: {
      propertyId: contract?.propertyId?.toString() || "",
      tenantId: contract?.tenantId?.toString() || "",
      startDate: contract?.startDate || "",
      endDate: contract?.endDate || "",
      monthlyRent: contract?.monthlyRent || "",
      deposit: contract?.deposit || "",
      paymentDay: contract?.paymentDay?.toString() || "1",
      terms: contract?.terms || "",
      status: contract?.status || "active",
    },
  });

  const handleSubmit = (values: z.infer<typeof contractFormSchema>) => {
    const data: InsertContract = {
      propertyId: parseInt(values.propertyId),
      tenantId: parseInt(values.tenantId),
      startDate: values.startDate,
      endDate: values.endDate,
      monthlyRent: values.monthlyRent,
      deposit: values.deposit || null,
      paymentDay: values.paymentDay ? parseInt(values.paymentDay) : 1,
      terms: values.terms || null,
      status: values.status as "active" | "expired" | "terminated",
    };
    onSubmit(data);
  };

  const statusOptions = [
    { value: "active", label: "Aktywna" },
    { value: "expired", label: "Wygasła" },
    { value: "terminated", label: "Rozwiązana" },
  ];

  // Filter available properties (not rented)
  const availableProperties = properties.filter(p => p.status === "available" || p.id === contract?.propertyId);

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="propertyId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nieruchomość</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Wybierz nieruchomość" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {availableProperties.map((property) => (
                      <SelectItem key={property.id} value={property.id.toString()}>
                        {property.address} - {property.monthlyRent} zł/mies.
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="tenantId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Najemca</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Wybierz najemcę" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {tenants.filter(t => t.isActive).map((tenant) => (
                      <SelectItem key={tenant.id} value={tenant.id.toString()}>
                        {tenant.firstName} {tenant.lastName} - {tenant.email}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="startDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Data rozpoczęcia</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="endDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Data zakończenia</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name="monthlyRent"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("monthlyRent")} (zł)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="2200" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="deposit"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("deposit")} (zł)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="4400" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="paymentDay"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Dzień płatności</FormLabel>
                <FormControl>
                  <Input type="number" min="1" max="31" placeholder="1" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="status"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Status umowy</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {statusOptions.map((status) => (
                    <SelectItem key={status.value} value={status.value}>
                      {status.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="terms"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Warunki umowy</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Dodatkowe warunki i klauzule umowy..."
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-3 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            {t("cancel")}
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Zapisywanie..." : t("save")}
          </Button>
        </div>
      </form>
    </Form>
  );
}
