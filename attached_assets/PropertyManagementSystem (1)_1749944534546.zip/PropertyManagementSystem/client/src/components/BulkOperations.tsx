import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Download, Upload, FileSpreadsheet, Plus } from "lucide-react";

interface BulkOperationsProps {
  module: 'properties' | 'tenants' | 'contracts' | 'payments' | 'service-requests';
  onSuccess?: () => void;
}

export function BulkOperations({ module, onSuccess }: BulkOperationsProps) {
  const [isImporting, setIsImporting] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const response = await fetch(`/api/${module}/export`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Export failed');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${module}_export_${new Date().toISOString().split('T')[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Eksport ukończony",
        description: `Dane ${module} zostały wyeksportowane do pliku Excel.`,
      });
    } catch (error) {
      toast({
        title: "Błąd eksportu",
        description: "Nie udało się wyeksportować danych.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch(`/api/${module}/import`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Import failed');
      }

      toast({
        title: "Import ukończony",
        description: `Dane z pliku zostały zaimportowane do ${module}.`,
      });
      
      onSuccess?.();
    } catch (error) {
      toast({
        title: "Błąd importu",
        description: "Nie udało się zaimportować danych z pliku.",
        variant: "destructive",
      });
    } finally {
      setIsImporting(false);
      // Reset file input
      event.target.value = '';
    }
  };

  const downloadTemplate = async () => {
    try {
      const response = await fetch(`/api/${module}/template`, {
        method: 'GET',
      });

      if (!response.ok) {
        throw new Error('Template download failed');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${module}_template.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Szablon pobrany",
        description: "Możesz teraz wypełnić szablon i zaimportować dane.",
      });
    } catch (error) {
      toast({
        title: "Błąd pobierania",
        description: "Nie udało się pobrać szablonu.",
        variant: "destructive",
      });
    }
  };

  const moduleNames = {
    'properties': 'nieruchomości',
    'tenants': 'najemców',
    'contracts': 'umowy',
    'payments': 'płatności',
    'service-requests': 'zgłoszenia serwisowe'
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5" />
          Operacje masowe - {moduleNames[module]}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-3 gap-4">
          {/* Export */}
          <div className="space-y-2">
            <Label>Eksport do Excel</Label>
            <Button 
              onClick={handleExport}
              disabled={isExporting}
              className="w-full"
              variant="outline"
            >
              <Download className="h-4 w-4 mr-2" />
              {isExporting ? 'Eksportowanie...' : 'Eksportuj'}
            </Button>
          </div>

          {/* Import Template */}
          <div className="space-y-2">
            <Label>Pobierz szablon</Label>
            <Button 
              onClick={downloadTemplate}
              className="w-full"
              variant="outline"
            >
              <Plus className="h-4 w-4 mr-2" />
              Pobierz szablon
            </Button>
          </div>

          {/* Import */}
          <div className="space-y-2">
            <Label htmlFor={`import-${module}`}>Import z Excel</Label>
            <div className="relative">
              <Input
                id={`import-${module}`}
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleImport}
                disabled={isImporting}
                className="cursor-pointer"
              />
              {isImporting && (
                <div className="absolute inset-0 bg-gray-50 bg-opacity-75 flex items-center justify-center">
                  <span className="text-sm">Importowanie...</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="mt-4 p-3 bg-blue-50 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">Instrukcje:</h4>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>1. Pobierz szablon Excel aby zobaczyć wymagane kolumny</li>
            <li>2. Wypełnij szablon danymi</li>
            <li>3. Zaimportuj wypełniony plik</li>
            <li>4. Użyj eksportu aby pobrać aktualne dane</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}