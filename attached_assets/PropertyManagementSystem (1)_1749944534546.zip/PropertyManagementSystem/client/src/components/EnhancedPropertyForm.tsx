import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPropertySchema, type InsertProperty, type Property } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { MapPin, Building2, Euro, FileText, Image, Plus } from "lucide-react";

interface EnhancedPropertyFormProps {
  property?: Property;
  onSubmit: (data: InsertProperty) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function EnhancedPropertyForm({ property, onSubmit, onCancel, isLoading }: EnhancedPropertyFormProps) {
  const { t } = useLanguage();
  const [imageFiles, setImageFiles] = useState<FileList | null>(null);
  
  const form = useForm<InsertProperty>({
    resolver: zodResolver(insertPropertySchema),
    defaultValues: {
      address: property?.address || "",
      type: property?.type || "apartment",
      area: property?.area || "",
      rooms: property?.rooms || 1,
      bathrooms: property?.bathrooms || 1,
      monthlyRent: property?.monthlyRent || "",
      deposit: property?.deposit || "",
      status: property?.status || "available",
      description: property?.description || "",
    },
  });

  const handleSubmit = (data: InsertProperty) => {
    // Add image handling logic here if needed
    onSubmit(data);
  };

  // Removed amenities functionality for now to match current schema

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building2 className="h-5 w-5" />
          {property ? t("editProperty") : t("addProperty")}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
          {/* Basic Information */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">{t("propertyName")} *</Label>
              <Input
                id="name"
                {...form.register("name")}
                placeholder={t("enterPropertyName")}
                className="w-full"
              />
              {form.formState.errors.name && (
                <p className="text-sm text-red-600">{form.formState.errors.name.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="propertyType">{t("propertyType")} *</Label>
              <Select value={form.watch("propertyType")} onValueChange={(value) => form.setValue("propertyType", value as any)}>
                <SelectTrigger>
                  <SelectValue placeholder={t("selectPropertyType")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="apartment">{t("apartment")}</SelectItem>
                  <SelectItem value="house">{t("house")}</SelectItem>
                  <SelectItem value="studio">{t("studio")}</SelectItem>
                  <SelectItem value="commercial">{t("commercial")}</SelectItem>
                  <SelectItem value="office">{t("office")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Address Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              {t("address")}
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="address">{t("streetAddress")} *</Label>
                <Input
                  id="address"
                  {...form.register("address")}
                  placeholder={t("enterAddress")}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="city">{t("city")} *</Label>
                <Input
                  id="city"
                  {...form.register("city")}
                  placeholder={t("enterCity")}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="postalCode">{t("postalCode")}</Label>
                <Input
                  id="postalCode"
                  {...form.register("postalCode")}
                  placeholder="00-000"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="country">{t("country")}</Label>
                <Select value={form.watch("country")} onValueChange={(value) => form.setValue("country", value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Poland">Poland</SelectItem>
                    <SelectItem value="Denmark">Denmark</SelectItem>
                    <SelectItem value="United Kingdom">United Kingdom</SelectItem>
                    <SelectItem value="Germany">Germany</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Property Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">{t("propertyDetails")}</h3>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="bedrooms">{t("bedrooms")}</Label>
                <Input
                  id="bedrooms"
                  type="number"
                  min="0"
                  {...form.register("bedrooms", { valueAsNumber: true })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bathrooms">{t("bathrooms")}</Label>
                <Input
                  id="bathrooms"
                  type="number"
                  min="0"
                  step="0.5"
                  {...form.register("bathrooms", { valueAsNumber: true })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="area">{t("area")} (m²)</Label>
                <Input
                  id="area"
                  type="number"
                  min="0"
                  {...form.register("area", { valueAsNumber: true })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="parkingSpaces">{t("parkingSpaces")}</Label>
                <Input
                  id="parkingSpaces"
                  type="number"
                  min="0"
                  {...form.register("parkingSpaces", { valueAsNumber: true })}
                />
              </div>
            </div>
          </div>

          {/* Financial Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Euro className="h-4 w-4" />
              {t("financialInfo")}
            </h3>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="rent">{t("monthlyRent")} (PLN) *</Label>
                <Input
                  id="rent"
                  type="number"
                  min="0"
                  step="0.01"
                  {...form.register("rent", { valueAsNumber: true })}
                  placeholder="2500.00"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="deposit">{t("securityDeposit")} (PLN)</Label>
                <Input
                  id="deposit"
                  type="number"
                  min="0"
                  step="0.01"
                  {...form.register("deposit", { valueAsNumber: true })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="utilities">{t("utilities")}</Label>
                <Select value={form.watch("utilities")} onValueChange={(value) => form.setValue("utilities", value as any)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="included">{t("included")}</SelectItem>
                    <SelectItem value="excluded">{t("excluded")}</SelectItem>
                    <SelectItem value="partial">{t("partial")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Property Status and Availability */}
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="status">{t("status")}</Label>
              <Select value={form.watch("status")} onValueChange={(value) => form.setValue("status", value as any)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">{t("available")}</SelectItem>
                  <SelectItem value="rented">{t("rented")}</SelectItem>
                  <SelectItem value="maintenance">{t("maintenance")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="furnished">{t("furnished")}</Label>
              <Select value={form.watch("furnished") ? "yes" : "no"} onValueChange={(value) => form.setValue("furnished", value === "yes")}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="yes">{t("yes")}</SelectItem>
                  <SelectItem value="no">{t("no")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="availableFrom">{t("availableFrom")}</Label>
              <Input
                id="availableFrom"
                type="date"
                {...form.register("availableFrom")}
              />
            </div>
          </div>

          {/* Pet Policy */}
          <div className="space-y-2">
            <Label htmlFor="petPolicy">{t("petPolicy")}</Label>
            <Select value={form.watch("petPolicy")} onValueChange={(value) => form.setValue("petPolicy", value as any)}>
              <SelectTrigger className="w-full md:w-1/3">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="allowed">{t("petsAllowed")}</SelectItem>
                <SelectItem value="not_allowed">{t("petsNotAllowed")}</SelectItem>
                <SelectItem value="cats_only">{t("catsOnly")}</SelectItem>
                <SelectItem value="dogs_only">{t("dogsOnly")}</SelectItem>
                <SelectItem value="negotiable">{t("negotiable")}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Amenities */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>{t("amenities")}</Label>
              <Button type="button" onClick={addAmenity} variant="outline" size="sm">
                <Plus className="h-4 w-4 mr-1" />
                {t("addAmenity")}
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {(form.watch("amenities") || []).map((amenity, index) => (
                <div
                  key={index}
                  className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm flex items-center gap-2"
                >
                  {amenity}
                  <button
                    type="button"
                    onClick={() => removeAmenity(amenity)}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">{t("description")}</Label>
            <Textarea
              id="description"
              {...form.register("description")}
              placeholder={t("enterPropertyDescription")}
              rows={4}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-6 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              {t("cancel")}
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? t("saving") : property ? t("update") : t("create")}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}