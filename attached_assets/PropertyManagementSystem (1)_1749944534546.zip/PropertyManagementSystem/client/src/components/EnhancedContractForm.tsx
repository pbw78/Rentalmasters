import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery } from "@tanstack/react-query";
import { insertContractSchema, type InsertContract, type Contract, type Property, type Tenant } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { FileText, Building, User, Calendar, Euro, AlertCircle } from "lucide-react";

interface EnhancedContractFormProps {
  contract?: Contract;
  onSubmit: (data: InsertContract) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function EnhancedContractForm({ contract, onSubmit, onCancel, isLoading }: EnhancedContractFormProps) {
  const { t } = useLanguage();
  
  const { data: properties = [] } = useQuery<Property[]>({
    queryKey: ["/api/properties"],
  });

  const { data: tenants = [] } = useQuery<Tenant[]>({
    queryKey: ["/api/tenants"],
  });

  const form = useForm<InsertContract>({
    resolver: zodResolver(insertContractSchema),
    defaultValues: {
      propertyId: contract?.propertyId || 0,
      tenantId: contract?.tenantId || 0,
      startDate: contract?.startDate || "",
      endDate: contract?.endDate || "",
      monthlyRent: contract?.monthlyRent || "",
      deposit: contract?.deposit || "",
      terms: contract?.terms || "",
      status: contract?.status || "active",
    },
  });

  const selectedProperty = properties.find(p => p.id === form.watch("propertyId"));
  const selectedTenant = tenants.find(t => t.id === form.watch("tenantId"));

  const handleSubmit = (data: InsertContract) => {
    onSubmit(data);
  };

  const calculateEndDate = (startDate: string, months: number = 12) => {
    if (!startDate) return "";
    const start = new Date(startDate);
    start.setMonth(start.getMonth() + months);
    return start.toISOString().split('T')[0];
  };

  const handleStartDateChange = (startDate: string) => {
    form.setValue("startDate", startDate);
    if (startDate && !form.getValues("endDate")) {
      form.setValue("endDate", calculateEndDate(startDate));
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          {contract ? t("editContract") : t("createContract")}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
          {/* Property and Tenant Selection */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Building className="h-4 w-4" />
                {t("property")}
              </h3>
              <div className="space-y-2">
                <Label htmlFor="propertyId">{t("selectProperty")} *</Label>
                <Select
                  value={form.watch("propertyId")?.toString()}
                  onValueChange={(value) => form.setValue("propertyId", parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("selectProperty")} />
                  </SelectTrigger>
                  <SelectContent>
                    {properties
                      .filter(p => p.status === "available")
                      .map((property) => (
                        <SelectItem key={property.id} value={property.id.toString()}>
                          {property.address} - {property.monthlyRent} PLN
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.propertyId && (
                  <p className="text-sm text-red-600">{form.formState.errors.propertyId.message}</p>
                )}
              </div>
              
              {selectedProperty && (
                <div className="bg-blue-50 p-3 rounded-lg">
                  <h4 className="font-medium text-blue-900">{t("selectedProperty")}</h4>
                  <p className="text-sm text-blue-700">{selectedProperty.address}</p>
                  <p className="text-sm text-blue-700">{selectedProperty.type} • {selectedProperty.area}m²</p>
                  <p className="text-sm font-medium text-blue-800">{selectedProperty.monthlyRent} PLN/miesiąc</p>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <User className="h-4 w-4" />
                {t("tenant")}
              </h3>
              <div className="space-y-2">
                <Label htmlFor="tenantId">{t("selectTenant")} *</Label>
                <Select
                  value={form.watch("tenantId")?.toString()}
                  onValueChange={(value) => form.setValue("tenantId", parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("selectTenant")} />
                  </SelectTrigger>
                  <SelectContent>
                    {tenants
                      .filter(t => t.isActive)
                      .map((tenant) => (
                        <SelectItem key={tenant.id} value={tenant.id.toString()}>
                          {tenant.firstName} {tenant.lastName} - {tenant.email}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.tenantId && (
                  <p className="text-sm text-red-600">{form.formState.errors.tenantId.message}</p>
                )}
              </div>

              {selectedTenant && (
                <div className="bg-green-50 p-3 rounded-lg">
                  <h4 className="font-medium text-green-900">{t("selectedTenant")}</h4>
                  <p className="text-sm text-green-700">{selectedTenant.firstName} {selectedTenant.lastName}</p>
                  <p className="text-sm text-green-700">{selectedTenant.email}</p>
                  <p className="text-sm text-green-700">{selectedTenant.phone}</p>
                </div>
              )}
            </div>
          </div>

          {/* Contract Dates */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              {t("contractDates")}
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate">{t("startDate")} *</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={form.watch("startDate")}
                  onChange={(e) => handleStartDateChange(e.target.value)}
                />
                {form.formState.errors.startDate && (
                  <p className="text-sm text-red-600">{form.formState.errors.startDate.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="endDate">{t("endDate")} *</Label>
                <Input
                  id="endDate"
                  type="date"
                  {...form.register("endDate")}
                />
                {form.formState.errors.endDate && (
                  <p className="text-sm text-red-600">{form.formState.errors.endDate.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Financial Terms */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Euro className="h-4 w-4" />
              {t("financialTerms")}
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="monthlyRent">{t("monthlyRent")} (PLN) *</Label>
                <Input
                  id="monthlyRent"
                  {...form.register("monthlyRent")}
                  placeholder="2500.00"
                  value={selectedProperty?.monthlyRent || form.watch("monthlyRent")}
                />
                {form.formState.errors.monthlyRent && (
                  <p className="text-sm text-red-600">{form.formState.errors.monthlyRent.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="deposit">{t("securityDeposit")} (PLN)</Label>
                <Input
                  id="deposit"
                  {...form.register("deposit")}
                  placeholder="5000.00"
                  value={selectedProperty?.deposit || form.watch("deposit")}
                />
              </div>
            </div>
          </div>

          {/* Contract Status */}
          <div className="space-y-2">
            <Label htmlFor="status">{t("contractStatus")}</Label>
            <Select value={form.watch("status")} onValueChange={(value) => form.setValue("status", value as any)}>
              <SelectTrigger className="w-full md:w-1/3">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">{t("active")}</SelectItem>
                <SelectItem value="pending">{t("pending")}</SelectItem>
                <SelectItem value="expired">{t("expired")}</SelectItem>
                <SelectItem value="terminated">{t("terminated")}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Contract Terms */}
          <div className="space-y-2">
            <Label htmlFor="terms">{t("contractTerms")}</Label>
            <Textarea
              id="terms"
              {...form.register("terms")}
              placeholder={t("enterContractTerms")}
              rows={6}
              defaultValue={`1. Najemca zobowiązuje się do płacenia czynszu do 5. dnia każdego miesiąca.
2. Kaucja zabezpieczająca zostanie zwrócona po zakończeniu najmu, po potrąceniu ewentualnych szkód.
3. Najemca nie może podnajmować lokalu bez pisemnej zgody wynajmującego.
4. Najemca zobowiązuje się do utrzymania lokalu w dobrym stanie technicznym.
5. Wypowiedzenie umowy wymaga 30-dniowego okresu wypowiedzenia.`}
            />
          </div>

          {/* Warning Messages */}
          {selectedProperty && selectedProperty.status !== "available" && (
            <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-yellow-800">{t("warning")}</h4>
                <p className="text-sm text-yellow-700">
                  {t("propertyNotAvailable")}
                </p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-6 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              {t("cancel")}
            </Button>
            <Button 
              type="submit" 
              disabled={isLoading || !form.watch("propertyId") || !form.watch("tenantId")}
            >
              {isLoading ? t("saving") : contract ? t("update") : t("create")}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}