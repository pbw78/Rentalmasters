import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useLanguage } from "@/contexts/LanguageContext";
import { useQuery } from "@tanstack/react-query";
import type { ServiceRequest, InsertServiceRequest, Property, Tenant } from "@shared/schema";

const serviceRequestFormSchema = z.object({
  propertyId: z.string().min(1, "Nieruchomość jest wymagana"),
  tenantId: z.string().optional(),
  title: z.string().min(1, "Tytuł jest wymagany"),
  description: z.string().optional(),
  priority: z.string().default("medium"),
  status: z.string().default("open"),
  estimatedCost: z.string().optional(),
  actualCost: z.string().optional(),
  assignedTo: z.string().optional(),
  dueDate: z.string().optional(),
});

interface ServiceRequestFormProps {
  serviceRequest?: ServiceRequest;
  onSubmit: (data: InsertServiceRequest) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function ServiceRequestForm({ serviceRequest, onSubmit, onCancel, isLoading }: ServiceRequestFormProps) {
  const { t } = useLanguage();

  const { data: properties = [] } = useQuery<Property[]>({
    queryKey: ["/api/properties"],
  });

  const { data: tenants = [] } = useQuery<Tenant[]>({
    queryKey: ["/api/tenants"],
  });

  const form = useForm<z.infer<typeof serviceRequestFormSchema>>({
    resolver: zodResolver(serviceRequestFormSchema),
    defaultValues: {
      propertyId: serviceRequest?.propertyId?.toString() || "",
      tenantId: serviceRequest?.tenantId?.toString() || "",
      title: serviceRequest?.title || "",
      description: serviceRequest?.description || "",
      priority: serviceRequest?.priority || "medium",
      status: serviceRequest?.status || "open",
      estimatedCost: serviceRequest?.estimatedCost || "",
      actualCost: serviceRequest?.actualCost || "",
      assignedTo: serviceRequest?.assignedTo || "",
      dueDate: serviceRequest?.dueDate ? serviceRequest.dueDate.toISOString().split('T')[0] : "",
    },
  });

  const handleSubmit = (values: z.infer<typeof serviceRequestFormSchema>) => {
    const data: InsertServiceRequest = {
      propertyId: parseInt(values.propertyId),
      tenantId: values.tenantId ? parseInt(values.tenantId) : null,
      title: values.title,
      description: values.description || null,
      priority: values.priority as "low" | "medium" | "high" | "urgent",
      status: values.status as "open" | "in_progress" | "completed" | "cancelled",
      estimatedCost: values.estimatedCost || null,
      actualCost: values.actualCost || null,
      assignedTo: values.assignedTo || null,
      dueDate: values.dueDate ? new Date(values.dueDate) : null,
    };
    onSubmit(data);
  };

  const priorityOptions = [
    { value: "low", label: "Niski", color: "bg-blue-100 text-blue-800" },
    { value: "medium", label: "Średni", color: "bg-yellow-100 text-yellow-800" },
    { value: "high", label: "Wysoki", color: "bg-orange-100 text-orange-800" },
    { value: "urgent", label: "Pilny", color: "bg-red-100 text-red-800" },
  ];

  const statusOptions = [
    { value: "open", label: "Otwarte" },
    { value: "in_progress", label: "W trakcie" },
    { value: "completed", label: "Zakończone" },
    { value: "cancelled", label: "Anulowane" },
  ];

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Tytuł zgłoszenia</FormLabel>
              <FormControl>
                <Input placeholder="Awaria instalacji wodnej" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="propertyId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nieruchomość</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Wybierz nieruchomość" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {properties.map((property) => (
                      <SelectItem key={property.id} value={property.id.toString()}>
                        {property.address}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="tenantId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Zgłaszający (opcjonalnie)</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Wybierz najemcę" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="">Brak</SelectItem>
                    {tenants.filter(t => t.isActive).map((tenant) => (
                      <SelectItem key={tenant.id} value={tenant.id.toString()}>
                        {tenant.firstName} {tenant.lastName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Opis problemu</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Szczegółowy opis zgłoszenia serwisowego..."
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="priority"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Priorytet</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {priorityOptions.map((priority) => (
                      <SelectItem key={priority.value} value={priority.value}>
                        {priority.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {statusOptions.map((status) => (
                      <SelectItem key={status.value} value={status.value}>
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="estimatedCost"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Szacowany koszt (zł)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="800" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="actualCost"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Rzeczywisty koszt (zł)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="750" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="assignedTo"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Przypisane do</FormLabel>
                <FormControl>
                  <Input placeholder="Firma Serwis Sp. z o.o." {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="dueDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Termin realizacji</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex justify-end space-x-3 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            {t("cancel")}
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Zapisywanie..." : t("save")}
          </Button>
        </div>
      </form>
    </Form>
  );
}
