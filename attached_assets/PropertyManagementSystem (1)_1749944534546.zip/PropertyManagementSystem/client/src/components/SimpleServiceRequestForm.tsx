import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertServiceRequestSchema, type InsertServiceRequest, type ServiceRequest } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { Wrench } from "lucide-react";

interface SimpleServiceRequestFormProps {
  serviceRequest?: ServiceRequest;
  onSubmit: (data: InsertServiceRequest) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function SimpleServiceRequestForm({ serviceRequest, onSubmit, onCancel, isLoading }: SimpleServiceRequestFormProps) {
  const { t } = useLanguage();
  
  const { data: properties = [] } = useQuery({
    queryKey: ["/api/properties"],
  });

  const { data: tenants = [] } = useQuery({
    queryKey: ["/api/tenants"],
  });
  
  const form = useForm<InsertServiceRequest>({
    resolver: zodResolver(insertServiceRequestSchema),
    defaultValues: {
      title: serviceRequest?.title || "",
      propertyId: serviceRequest?.propertyId || undefined,
      tenantId: serviceRequest?.tenantId || undefined,
      description: serviceRequest?.description || "",
      priority: serviceRequest?.priority || "medium",
      status: serviceRequest?.status || "open",
      estimatedCost: serviceRequest?.estimatedCost || "",
      actualCost: serviceRequest?.actualCost || "",
      assignedTo: serviceRequest?.assignedTo || "",
      dueDate: serviceRequest?.dueDate ? new Date(serviceRequest.dueDate).toISOString().split('T')[0] : undefined,
    },
  });

  const handleSubmit = (data: InsertServiceRequest) => {
    onSubmit(data);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wrench className="h-5 w-5" />
          {serviceRequest ? "Edytuj zgłoszenie" : "Dodaj zgłoszenie serwisowe"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Tytuł *</Label>
            <Input
              id="title"
              {...form.register("title")}
              placeholder="Naprawa kranu w łazience"
            />
            {form.formState.errors.title && (
              <p className="text-sm text-red-600">{form.formState.errors.title.message}</p>
            )}
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="propertyId">Nieruchomość *</Label>
              <Select 
                value={form.watch("propertyId")?.toString()} 
                onValueChange={(value) => form.setValue("propertyId", parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Wybierz nieruchomość" />
                </SelectTrigger>
                <SelectContent>
                  {(properties as any[]).map((property: any) => (
                    <SelectItem key={property.id} value={property.id.toString()}>
                      {property.address}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.propertyId && (
                <p className="text-sm text-red-600">{form.formState.errors.propertyId.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="tenantId">Najemca</Label>
              <Select 
                value={form.watch("tenantId")?.toString() || ""} 
                onValueChange={(value) => form.setValue("tenantId", value ? parseInt(value) : null)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Wybierz najemcę (opcjonalne)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Brak najemcy</SelectItem>
                  {(tenants as any[]).map((tenant: any) => (
                    <SelectItem key={tenant.id} value={tenant.id.toString()}>
                      {tenant.firstName} {tenant.lastName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Opis</Label>
            <Textarea
              id="description"
              {...form.register("description")}
              placeholder="Szczegółowy opis problemu..."
              rows={3}
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="priority">Priorytet</Label>
              <Select 
                value={form.watch("priority") || "medium"} 
                onValueChange={(value) => form.setValue("priority", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Niski</SelectItem>
                  <SelectItem value="medium">Średni</SelectItem>
                  <SelectItem value="high">Wysoki</SelectItem>
                  <SelectItem value="urgent">Pilny</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select 
                value={form.watch("status") || "open"} 
                onValueChange={(value) => form.setValue("status", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="open">Otwarte</SelectItem>
                  <SelectItem value="in_progress">W trakcie</SelectItem>
                  <SelectItem value="completed">Zakończone</SelectItem>
                  <SelectItem value="cancelled">Anulowane</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="estimatedCost">Szacowany koszt (PLN)</Label>
              <Input
                id="estimatedCost"
                {...form.register("estimatedCost")}
                placeholder="500.00"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="actualCost">Rzeczywisty koszt (PLN)</Label>
              <Input
                id="actualCost"
                {...form.register("actualCost")}
                placeholder="450.00"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDate">Termin wykonania</Label>
              <Input
                id="dueDate"
                type="date"
                {...form.register("dueDate")}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="assignedTo">Przypisane do</Label>
            <Input
              id="assignedTo"
              {...form.register("assignedTo")}
              placeholder="Jan Kowalski - hydraulik"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Anuluj
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Zapisywanie..." : serviceRequest ? "Aktualizuj" : "Utwórz"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}