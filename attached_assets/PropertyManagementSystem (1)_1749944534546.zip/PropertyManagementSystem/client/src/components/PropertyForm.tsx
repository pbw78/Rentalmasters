import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useLanguage } from "@/contexts/LanguageContext";
import type { Property, InsertProperty } from "@shared/schema";

const propertyFormSchema = z.object({
  address: z.string().min(1, "Adres jest wymagany"),
  type: z.string().min(1, "Typ nieruchomości jest wymagany"),
  area: z.string().optional(),
  rooms: z.string().optional(),
  bathrooms: z.string().optional(),
  monthlyRent: z.string().min(1, "Czynsz miesięczny jest wymagany"),
  deposit: z.string().optional(),
  description: z.string().optional(),
  status: z.string().default("available"),
});

interface PropertyFormProps {
  property?: Property;
  onSubmit: (data: InsertProperty) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function PropertyForm({ property, onSubmit, onCancel, isLoading }: PropertyFormProps) {
  const { t } = useLanguage();

  const form = useForm<z.infer<typeof propertyFormSchema>>({
    resolver: zodResolver(propertyFormSchema),
    defaultValues: {
      address: property?.address || "",
      type: property?.type || "",
      area: property?.area || "",
      rooms: property?.rooms?.toString() || "",
      bathrooms: property?.bathrooms?.toString() || "",
      monthlyRent: property?.monthlyRent || "",
      deposit: property?.deposit || "",
      description: property?.description || "",
      status: property?.status || "available",
    },
  });

  const handleSubmit = (values: z.infer<typeof propertyFormSchema>) => {
    const data: InsertProperty = {
      address: values.address,
      type: values.type,
      area: values.area ? values.area : null,
      rooms: values.rooms ? parseInt(values.rooms) : null,
      bathrooms: values.bathrooms ? parseInt(values.bathrooms) : null,
      monthlyRent: values.monthlyRent,
      deposit: values.deposit || null,
      description: values.description || null,
      status: values.status as "available" | "rented" | "maintenance" | "unavailable",
    };
    onSubmit(data);
  };

  const propertyTypes = [
    { value: "apartment", label: "Mieszkanie" },
    { value: "house", label: "Dom" },
    { value: "studio", label: "Studio" },
    { value: "townhouse", label: "Kamienica" },
    { value: "loft", label: "Loft" },
  ];

  const statusOptions = [
    { value: "available", label: t("available") },
    { value: "rented", label: t("rented") },
    { value: "maintenance", label: t("maintenance") },
    { value: "unavailable", label: t("unavailable") },
  ];

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="address"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("address")}</FormLabel>
                <FormControl>
                  <Input placeholder="ul. Mickiewicza 15/3" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("type")}</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Wybierz typ nieruchomości" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {propertyTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name="area"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("area")} (m²)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="65" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="rooms"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("rooms")}</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="3" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="bathrooms"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("bathrooms")}</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="1" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="monthlyRent"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("monthlyRent")} (zł)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="2200" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="deposit"
            render={({ field }) => (
              <FormItem>
                <FormLabel>{t("deposit")} (zł)</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="4400" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="status"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Status</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {statusOptions.map((status) => (
                    <SelectItem key={status.value} value={status.value}>
                      {status.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>{t("description")}</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Dodatkowe informacje o nieruchomości..."
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-3 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>
            {t("cancel")}
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Zapisywanie..." : t("save")}
          </Button>
        </div>
      </form>
    </Form>
  );
}
