import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery } from "@tanstack/react-query";
import { insertServiceRequestSchema, type InsertServiceRequest, type ServiceRequest, type Property, type Tenant } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { Wrench, Building, User, AlertTriangle, Calendar } from "lucide-react";

interface EnhancedServiceRequestFormProps {
  serviceRequest?: ServiceRequest;
  onSubmit: (data: InsertServiceRequest) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function EnhancedServiceRequestForm({ serviceRequest, onSubmit, onCancel, isLoading }: EnhancedServiceRequestFormProps) {
  const { t } = useLanguage();
  
  const { data: properties = [] } = useQuery<Property[]>({
    queryKey: ["/api/properties"],
  });

  const { data: tenants = [] } = useQuery<Tenant[]>({
    queryKey: ["/api/tenants"],
  });

  const form = useForm<InsertServiceRequest>({
    resolver: zodResolver(insertServiceRequestSchema),
    defaultValues: {
      title: serviceRequest?.title || "",
      description: serviceRequest?.description || "",
      propertyId: serviceRequest?.propertyId || 0,
      tenantId: serviceRequest?.tenantId || null,
      priority: serviceRequest?.priority || "medium",
      status: serviceRequest?.status || "open",
      category: serviceRequest?.category || "maintenance",
    },
  });

  const selectedProperty = properties.find(p => p.id === form.watch("propertyId"));

  const handleSubmit = (data: InsertServiceRequest) => {
    onSubmit(data);
  };

  const priorityColors = {
    low: "bg-green-100 text-green-800",
    medium: "bg-yellow-100 text-yellow-800",
    high: "bg-orange-100 text-orange-800",
    urgent: "bg-red-100 text-red-800"
  };

  const statusColors = {
    open: "bg-blue-100 text-blue-800",
    in_progress: "bg-yellow-100 text-yellow-800",
    resolved: "bg-green-100 text-green-800",
    closed: "bg-gray-100 text-gray-800"
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wrench className="h-5 w-5" />
          {serviceRequest ? "Edytuj zgłoszenie serwisowe" : "Dodaj zgłoszenie serwisowe"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Podstawowe informacje</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Tytuł zgłoszenia *</Label>
                <Input
                  id="title"
                  {...form.register("title")}
                  placeholder="np. Awaria kranu w łazience"
                />
                {form.formState.errors.title && (
                  <p className="text-sm text-red-600">{form.formState.errors.title.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Opis problemu *</Label>
                <Textarea
                  id="description"
                  {...form.register("description")}
                  placeholder="Opisz szczegółowo problem, który należy naprawić..."
                  rows={4}
                />
                {form.formState.errors.description && (
                  <p className="text-sm text-red-600">{form.formState.errors.description.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Property and Tenant Selection */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Building className="h-4 w-4" />
                Nieruchomość
              </h3>
              <div className="space-y-2">
                <Label htmlFor="propertyId">Wybierz nieruchomość *</Label>
                <Select
                  value={form.watch("propertyId")?.toString()}
                  onValueChange={(value) => form.setValue("propertyId", parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Wybierz nieruchomość" />
                  </SelectTrigger>
                  <SelectContent>
                    {properties.map((property) => (
                      <SelectItem key={property.id} value={property.id.toString()}>
                        {property.address} ({property.type})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.propertyId && (
                  <p className="text-sm text-red-600">{form.formState.errors.propertyId.message}</p>
                )}
              </div>

              {selectedProperty && (
                <div className="bg-blue-50 p-3 rounded-lg">
                  <h4 className="font-medium text-blue-900">Wybrana nieruchomość</h4>
                  <p className="text-sm text-blue-700">{selectedProperty.address}</p>
                  <p className="text-sm text-blue-700">Typ: {selectedProperty.type}</p>
                  <p className="text-sm text-blue-700">Status: {selectedProperty.status}</p>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <User className="h-4 w-4" />
                Najemca (opcjonalnie)
              </h3>
              <div className="space-y-2">
                <Label htmlFor="tenantId">Zgłaszający najemca</Label>
                <Select
                  value={form.watch("tenantId")?.toString() || ""}
                  onValueChange={(value) => form.setValue("tenantId", value ? parseInt(value) : null)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Wybierz najemcę (opcjonalnie)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Brak najemcy</SelectItem>
                    {tenants
                      .filter(t => t.isActive)
                      .map((tenant) => (
                        <SelectItem key={tenant.id} value={tenant.id.toString()}>
                          {tenant.firstName} {tenant.lastName} - {tenant.email}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Category and Priority */}
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Kategoria</Label>
              <Select value={form.watch("category")} onValueChange={(value) => form.setValue("category", value as any)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="maintenance">Konserwacja</SelectItem>
                  <SelectItem value="repair">Naprawa</SelectItem>
                  <SelectItem value="plumbing">Hydraulika</SelectItem>
                  <SelectItem value="electrical">Elektryka</SelectItem>
                  <SelectItem value="heating">Ogrzewanie</SelectItem>
                  <SelectItem value="cleaning">Sprzątanie</SelectItem>
                  <SelectItem value="security">Bezpieczeństwo</SelectItem>
                  <SelectItem value="other">Inne</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority">Priorytet</Label>
              <Select value={form.watch("priority")} onValueChange={(value) => form.setValue("priority", value as any)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-green-500"></div>
                      Niski
                    </div>
                  </SelectItem>
                  <SelectItem value="medium">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                      Średni
                    </div>
                  </SelectItem>
                  <SelectItem value="high">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                      Wysoki
                    </div>
                  </SelectItem>
                  <SelectItem value="urgent">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-red-500"></div>
                      Pilny
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={form.watch("status")} onValueChange={(value) => form.setValue("status", value as any)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="open">Otwarte</SelectItem>
                  <SelectItem value="in_progress">W trakcie</SelectItem>
                  <SelectItem value="resolved">Rozwiązane</SelectItem>
                  <SelectItem value="closed">Zamknięte</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Quick Templates */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-medium mb-3">Szablony zgłoszeń</h4>
            <div className="grid md:grid-cols-2 gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  form.setValue("title", "Awaria kranu w łazience");
                  form.setValue("description", "Kran w łazience nie działa prawidłowo - potrzebna naprawa lub wymiana.");
                  form.setValue("category", "plumbing");
                  form.setValue("priority", "medium");
                }}
              >
                Awaria hydrauliczna
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  form.setValue("title", "Problem z ogrzewaniem");
                  form.setValue("description", "Grzejniki nie grzeją lub grzeją słabo. Wymagana kontrola systemu ogrzewania.");
                  form.setValue("category", "heating");
                  form.setValue("priority", "high");
                }}
              >
                Problem z ogrzewaniem
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  form.setValue("title", "Awaria instalacji elektrycznej");
                  form.setValue("description", "Brak prądu w części mieszkania lub nieprawidłowe działanie gniazdek.");
                  form.setValue("category", "electrical");
                  form.setValue("priority", "high");
                }}
              >
                Awaria elektryczna
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  form.setValue("title", "Sprzątanie po remoncie");
                  form.setValue("description", "Wymagane generalne sprzątanie mieszkania po zakończonych pracach remontowych.");
                  form.setValue("category", "cleaning");
                  form.setValue("priority", "low");
                }}
              >
                Sprzątanie
              </Button>
            </div>
          </div>

          {/* Priority Alert */}
          {(form.watch("priority") === "urgent" || form.watch("priority") === "high") && (
            <div className="bg-orange-50 border border-orange-200 p-4 rounded-lg flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-orange-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-orange-800">Wysoki priorytet</h4>
                <p className="text-sm text-orange-700">
                  To zgłoszenie ma wysoki priorytet i wymaga szybkiej reakcji.
                </p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-6 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Anuluj
            </Button>
            <Button 
              type="submit" 
              disabled={isLoading || !form.watch("propertyId") || !form.watch("title")}
            >
              {isLoading ? "Zapisywanie..." : serviceRequest ? "Aktualizuj" : "Utwórz zgłoszenie"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}