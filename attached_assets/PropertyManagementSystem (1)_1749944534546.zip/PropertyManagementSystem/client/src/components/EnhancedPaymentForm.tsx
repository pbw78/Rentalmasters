import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery } from "@tanstack/react-query";
import { insertPaymentSchema, type InsertPayment, type Payment, type ContractWithRelations } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { CreditCard, FileText, Calendar, Euro, AlertCircle } from "lucide-react";

interface EnhancedPaymentFormProps {
  payment?: Payment;
  onSubmit: (data: InsertPayment) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function EnhancedPaymentForm({ payment, onSubmit, onCancel, isLoading }: EnhancedPaymentFormProps) {
  const { t } = useLanguage();
  
  const { data: contracts = [] } = useQuery<ContractWithRelations[]>({
    queryKey: ["/api/contracts"],
  });

  const form = useForm<InsertPayment>({
    resolver: zodResolver(insertPaymentSchema),
    defaultValues: {
      contractId: payment?.contractId || 0,
      amount: payment?.amount || "",
      dueDate: payment?.dueDate || "",
      paymentDate: payment?.paymentDate || "",
      paymentMethod: payment?.paymentMethod || "bank_transfer",
      status: payment?.status || "pending",
    },
  });

  const selectedContract = contracts.find(c => c.id === form.watch("contractId"));

  const handleSubmit = (data: InsertPayment) => {
    onSubmit(data);
  };

  const generateDueDate = () => {
    const today = new Date();
    const nextMonth = new Date(today.getFullYear(), today.getMonth() + 1, 5); // 5th of next month
    return nextMonth.toISOString().split('T')[0];
  };

  const setMonthlyRent = () => {
    if (selectedContract) {
      form.setValue("amount", selectedContract.monthlyRent);
      if (!form.getValues("dueDate")) {
        form.setValue("dueDate", generateDueDate());
      }
    }
  };

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="h-5 w-5" />
          {payment ? "Edytuj płatność" : "Dodaj płatność"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
          {/* Contract Selection */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Wybór umowy
            </h3>
            <div className="space-y-2">
              <Label htmlFor="contractId">Umowa *</Label>
              <Select
                value={form.watch("contractId")?.toString()}
                onValueChange={(value) => {
                  form.setValue("contractId", parseInt(value));
                  setTimeout(setMonthlyRent, 100); // Allow state to update
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Wybierz umowę" />
                </SelectTrigger>
                <SelectContent>
                  {contracts
                    .filter(c => c.status === "active")
                    .map((contract) => (
                      <SelectItem key={contract.id} value={contract.id.toString()}>
                        {contract.property.address} - {contract.tenant.firstName} {contract.tenant.lastName} ({contract.monthlyRent} PLN)
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
              {form.formState.errors.contractId && (
                <p className="text-sm text-red-600">{form.formState.errors.contractId.message}</p>
              )}
            </div>

            {selectedContract && (
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900">Szczegóły umowy</h4>
                <div className="grid md:grid-cols-2 gap-4 mt-2 text-sm text-blue-700">
                  <div>
                    <p><strong>Nieruchomość:</strong> {selectedContract.property.address}</p>
                    <p><strong>Najemca:</strong> {selectedContract.tenant.firstName} {selectedContract.tenant.lastName}</p>
                  </div>
                  <div>
                    <p><strong>Czynsz miesięczny:</strong> {selectedContract.monthlyRent} PLN</p>
                    <p><strong>Okres:</strong> {selectedContract.startDate} - {selectedContract.endDate}</p>
                  </div>
                </div>
                <Button
                  type="button"
                  onClick={setMonthlyRent}
                  variant="outline"
                  size="sm"
                  className="mt-3"
                >
                  Ustaw czynsz miesięczny
                </Button>
              </div>
            )}
          </div>

          {/* Payment Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Euro className="h-4 w-4" />
              Szczegóły płatności
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Kwota (PLN) *</Label>
                <Input
                  id="amount"
                  {...form.register("amount")}
                  placeholder="2500.00"
                />
                {form.formState.errors.amount && (
                  <p className="text-sm text-red-600">{form.formState.errors.amount.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="paymentMethod">Metoda płatności</Label>
                <Select value={form.watch("paymentMethod")} onValueChange={(value) => form.setValue("paymentMethod", value as any)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bank_transfer">Przelew bankowy</SelectItem>
                    <SelectItem value="cash">Gotówka</SelectItem>
                    <SelectItem value="card">Karta</SelectItem>
                    <SelectItem value="blik">BLIK</SelectItem>
                    <SelectItem value="online">Płatność online</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Dates */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Terminy
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dueDate">Termin płatności *</Label>
                <Input
                  id="dueDate"
                  type="date"
                  {...form.register("dueDate")}
                />
                {form.formState.errors.dueDate && (
                  <p className="text-sm text-red-600">{form.formState.errors.dueDate.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="paymentDate">Data płatności</Label>
                <Input
                  id="paymentDate"
                  type="date"
                  {...form.register("paymentDate")}
                />
              </div>
            </div>
          </div>

          {/* Payment Status */}
          <div className="space-y-2">
            <Label htmlFor="status">Status płatności</Label>
            <Select value={form.watch("status")} onValueChange={(value) => form.setValue("status", value as any)}>
              <SelectTrigger className="w-full md:w-1/3">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Oczekująca</SelectItem>
                <SelectItem value="paid">Opłacona</SelectItem>
                <SelectItem value="overdue">Przeterminowana</SelectItem>
                <SelectItem value="partial">Częściowa</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Quick Actions */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-medium mb-3">Szybkie akcje</h4>
            <div className="flex gap-2 flex-wrap">
              <Button
                type="button"
                onClick={() => form.setValue("dueDate", generateDueDate())}
                variant="outline"
                size="sm"
              >
                Ustaw termin na 5. następnego miesiąca
              </Button>
              <Button
                type="button"
                onClick={() => form.setValue("paymentDate", new Date().toISOString().split('T')[0])}
                variant="outline"
                size="sm"
              >
                Ustaw dzisiejszą datę
              </Button>
              <Button
                type="button"
                onClick={() => {
                  form.setValue("paymentDate", new Date().toISOString().split('T')[0]);
                  form.setValue("status", "paid");
                }}
                variant="outline"
                size="sm"
              >
                Oznacz jako opłacone
              </Button>
            </div>
          </div>

          {/* Warning for overdue */}
          {form.watch("dueDate") && new Date(form.watch("dueDate")) < new Date() && form.watch("status") === "pending" && (
            <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-yellow-800">Uwaga</h4>
                <p className="text-sm text-yellow-700">
                  Termin płatności już minął. Rozważ oznaczenie jako przeterminowaną.
                </p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-6 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Anuluj
            </Button>
            <Button 
              type="submit" 
              disabled={isLoading || !form.watch("contractId") || !form.watch("amount")}
            >
              {isLoading ? "Zapisywanie..." : payment ? "Aktualizuj" : "Utwórz"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}